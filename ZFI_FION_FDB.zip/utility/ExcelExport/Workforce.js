sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel"
], function (Object, JSONModel) {
	"use strict";
	return Object.extend("com.aramco.fion.fdbZFI_FION_FDB.utility.ExcelExport.Workforce", {
		getDataSource: function (type, _this) {
			var a = "",
				A = "";
			if (type === "WF_ORG") {
				a = _this.getView().byId("id_tab_workforce_org").getModel().getData().Items;
				A = a.slice();
				for (var i in A) {
					A[i].Data1 = _this.onAmountFormat(A[i].Data1);
					A[i].Data2 = _this.onAmountFormat(A[i].Data2);
					A[i].Data3 = _this.getVarianceNumber(A[i].Data1, A[i].Data2);
					A[i].Data4 = _this.getVariance(A[i].Data1, A[i].Data2);
				}
				return A;
			} else if (type === "WF_NAT") {
				a = _this.getView().getModel("MainModel").getData().NavHeadertoItem7.results;
				A = a.slice();
				for (var i in A) {
					A[i].Data1 = _this.onAmountFormat(A[i].Data1);
				}
				return A;
			} else if (type === "WF_SA_GRADE") {
				a = _this.getView().byId("id_tab_saudis_by_grade").getModel().getData().Items;
				A = a.slice();
				for (var i in A) {
					A[i].Data1 = _this.onAmountFormat(A[i].Data1);
					A[i].Data2 = _this.onAmountFormat(A[i].Data2);
					A[i].Data3 = _this.getVarianceNumber(A[i].Data1, A[i].Data2);
					A[i].Data4 = _this.getVariance(A[i].Data1, A[i].Data2);
				}
				return A;
			} else if (type === "WF_EXPAT_GRADE") {
				a = _this.getView().byId("id_tab_expat_by_grade").getModel().getData().Items;
				A = a.slice();
				for (var i in A) {
					A[i].Data1 = _this.onAmountFormat(A[i].Data1);
					A[i].Data2 = _this.onAmountFormat(A[i].Data2);
					A[i].Data3 = _this.getVarianceNumber(A[i].Data1, A[i].Data2);
					A[i].Data4 = _this.getVariance(A[i].Data1, A[i].Data2);
				}
				return A;
			} else if (type === "WF_SMP_SA_GRADE") {
				a = _this.getView().byId("id_tab_smp_saudi_by_grade").getModel().getData().Items;
				A = a.slice();
				for (var i in A) {
					A[i].Data1 = _this.onAmountFormat(A[i].Data1);
					A[i].Data2 = _this.onAmountFormat(A[i].Data2);
					A[i].Data3 = _this.getVarianceNumber(A[i].Data1, A[i].Data2);
					A[i].Data4 = _this.getVariance(A[i].Data1, A[i].Data2);
				}
				return A;
			} else if (type === "WF_SMP_EXPAT_GRADE") {
				a = _this.getView().byId("id_tab_smp_expat_by_grade").getModel().getData().Items;
				A = a.slice();
				for (var i in A) {
					A[i].Data1 = _this.onAmountFormat(A[i].Data1);
					A[i].Data2 = _this.onAmountFormat(A[i].Data2);
					A[i].Data3 = _this.getVarianceNumber(A[i].Data1, A[i].Data2);
					A[i].Data4 = _this.getVariance(A[i].Data1, A[i].Data2);
				}
				return A;
			}
		},
		getFileName: function (type, _this) {
			var oTitle = "";
			var oData = _this.getView().getModel("MainModel").getData();
			if (type === "WF_ORG") {
				return oData.Data5 + ".xlsx";
			} else if (type === "WF_NAT") {
				return oData.Data15 + ".xlsx";
			} else if (type === "WF_SA_GRADE") {
				return oData.Data7 + ".xlsx";
			} else if (type === "WF_EXPAT_GRADE") {
				return oData.Data8 + ".xlsx";
			} else if (type === "WF_SMP_SA_GRADE") {
				return oData.Data9 + ".xlsx";
			} else if (type === "WF_SMP_EXPAT_GRADE") {
				return oData.Data10 + ".xlsx";
			}
		},
		createColumns: function (type, _this) {
			if (type === "WF_ORG") {
				return [{
					label: "Item",
					property: "Item"
				}, {
					label: "Actual",
					property: "Data1"
				}, {
					label: "Plan",
					property: "Data2"
				}, {
					label: "Variance",
					property: "Data3"
				}, {
					label: "Variance (%)",
					property: "Data4"
				}];
			} else if (type === "WF_NAT") {
				return [{
					label: "Item",
					property: "Component"
				}, {
					label: "Values",
					property: "Data1"
				}];
			} else if (type === "WF_SA_GRADE" || type === "WF_EXPAT_GRADE" || type === "WF_SMP_SA_GRADE" || type === "WF_SMP_EXPAT_GRADE") {
				return [{
					label: "Item",
					property: "Item"
				}, {
					label: "Actual",
					property: "Data1"
				}, {
					label: "Plan",
					property: "Data2"
				}, {
					label: "Variance",
					property: "Data3"
				}, {
					label: "Variance (%)",
					property: "Data4"
				}];
			}
		}
	});
});
sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel"
], function (Object, JSONModel) {
	"use strict";
	return Object.extend("com.aramco.fion.fdbZFI_FION_FDB.utility.ExcelExport.ControllableCost", {
		getDataSource: function (type, _this) {
			var a = "",
				A = "";
			if (type === "CC_BY_ORG") {
				a = _this.getView().byId("id_tablecont_cost_org").getModel().getData().Items;
				A = a.slice();
				for (var i in A) {
					A[i].Data1 = _this.onAmountFormat(A[i].Data1);
					A[i].Data2 = _this.onAmountFormat(A[i].Data2);
					A[i].Data3 = _this.getVarianceNumber(A[i].Data1, A[i].Data2);
					A[i].Data4 = _this.getVariance(A[i].Data1, A[i].Data2);
				}
				return A;
			} else if (type === "CC_D_BY_ORG") {
				a = _this.getView().getModel("MainModel").getData().NavHeadertoItem2.results;
				A = a.slice();
				for (var i in A) {
					A[i].Data5 = _this.getMonths(A[i].Data5);
					A[i].Data1 = _this.onAmountFormat(A[i].Data1);
					A[i].Data2 = _this.onAmountFormat(A[i].Data2);
					A[i].Data3 = _this.onAmountFormat(A[i].Data3);
					A[i].Data4 = _this.onAmountFormat(A[i].Data4);

				}
				return A;
			} else if (type === "CC_OV_TIME") {
				a = _this.getView().getModel("MainModel").getData().NavHeadertoItem3.results;
				A = a.slice();
				for (var i in A) {
					A[i].CostElement = _this.getMonths(A[i].CostElement);
					A[i].Component = _this.onAmountFormat(A[i].Component);
					A[i].PlanVal = _this.onAmountFormat(A[i].PlanVal);
					A[i].Data3 = _this.getVarianceNumber(A[i].Component, A[i].PlanVal);
					A[i].Data4 = _this.getVariance(A[i].Component, A[i].PlanVal);
				}
				return A;
			} else if (type === "CC_REC_CAPEX") {
				a = _this.getView().getModel("MainModel").getData().NavHeadertoItem4.results;
				A = a.slice();
				for (var i in A) {
					A[i].Actual = _this.onAmountFormat(A[i].Actual);
				}
				return A;
			} else if (type === "CC_SERV_INC") {
				a = _this.getView().getModel("MainModel").getData().NavHeadertoItem5.results;
				A = a.slice();
				for (var i in A) {
					A[i].Value = _this.onAmountFormat(A[i].Value);
				}
				return A;
			}
		},
		getFileName: function (type, _this) {
			var oTitle = "";
			var oData = _this.getView().getModel("MainModel").getData();
			if (type === "CC_BY_ORG") {
				return oData.Data9 + ".xlsx";
			} else if (type === "CC_D_BY_ORG") {
				return oData.Data10 + ".xlsx";
			} else if (type === "CC_OV_TIME") {
				return oData.Data11 + ".xlsx";
			} else if (type === "CC_REC_CAPEX") {
				return oData.Data12 + ".xlsx";
			} else if (type === "CC_SERV_INC") {
				return oData.Data13 + ".xlsx";
			}
		},
		createColumns: function (type, _this) {
			if (type === "CC_BY_ORG") {
				return [{
					label: "Item",
					property: "Item"
				}, {
					label: "YTD Actual",
					property: "Data1"
				}, {
					label: "YTD Plan",
					property: "Data2"
				}, {
					label: "Variance",
					property: "Data3"
				}, {
					label: "Variance (%)",
					property: "Data4"
				}];
			} else if (type === "CC_D_BY_ORG") {
				return [{
					label: "Month",
					property: "Data5"
				}, {
					label: "Labour",
					property: "Data1"
				}, {
					label: "Material",
					property: "Data2"
				}, {
					label: "Services",
					property: "Data3"
				}, {
					label: "Power",
					property: "Data4"
				}];
			} else if (type === "CC_OV_TIME") {
				return [{
					label: "Month",
					property: "CostElement"
				}, {
					label: "YTD Actual",
					property: "Component"
				}, {
					label: "YTD Plan",
					property: "PlanVal"
				}, {
					label: "Variance",
					property: "Data3"
				}, {
					label: "Variance (%)",
					property: "Data4"
				}];
			} else if (type === "CC_REC_CAPEX") {
				return [{
					label: "Item",
					property: "CostElement"
				}, {
					label: "Values",
					property: "Actual"
				}];
			} else if (type === "CC_SERV_INC") {
				return [{
					label: "Item",
					property: "Component"
				}, {
					label: "Values",
					property: "Value"
				}];
			}
		}
	});
});
sap.ui.define([
	"sap/ui/base/Object",
	"sap/ui/model/json/JSONModel"
], function (Object, JSONModel) {
	"use strict";
	return Object.extend("com.aramco.fion.fdbZFI_FION_FDB.utility.ExportExcelExecSummary", {
		getDataSource: function (type, _this) {
			var a = "",
				A = "";
			if (type === "EXEC_DE") {
				a = _this.getView().byId("id_table_water_fall").getModel().getData().Items;
				A = a.slice();
				for (var i in A) {
					A[i].Data1 = _this.onAmountFormat(A[i].Data1);
					A[i].Data2 = _this.onAmountFormat(A[i].Data2);
					A[i].Data3 = _this.getVarianceNumber(A[i].Data1, A[i].Data2);
					A[i].Data4 = _this.getVariance(A[i].Data1, A[i].Data2);
				}
				return A;
			} else if (type === "EXEC_CC") {
				a = _this.getView().getModel("MainModel").getData().NavHeadertoItem4.results;
				A = a.slice();
				for (var i in A) {
					A[i].CostElement = _this.onAmountFormat(A[i].CostElement);
					A[i].Period = _this.onAmountFormat(A[i].Period);
				}
				return A;
			} else if (type === "EXEC_SUP_SERV") {
				a = _this.getView().getModel("MainModel").getData().NavHeadertoItem3.results;
				A = a.slice();
				for (var i in A) {
					A[i].PlanVal = _this.onAmountFormat(A[i].PlanVal);
				}
				return A;
			} else if (type === "EXEC_CST_ORG") {
				a = _this.getView().getModel("CostByORg").getData().Items;
				A = a.slice();
				for (var i in A) {
					A[i].Value = _this.onAmountFormat(A[i].Value);
				}
				return A;
			} else if (type === "EXEC_WRK_ORG") {
				a = _this.getView().getModel("MainModel").getData().NavHeadertoItem6.results;
				A = a.slice();
				for (var i in A) {
					A[i].Value = _this.onAmountFormat(A[i].Value);
				}
				return A;
			}
		},

		getFileName: function (type, _this) {
			var oTitle = "";
			var oData = _this.getView().getModel("MainModel").getData();
			if (type === "EXEC_DE") {
				return oData.Data9 + ".xlsx";
			} else if (type === "EXEC_CC") {
				return oData.Data10 + ".xlsx";
			} else if (type === "EXEC_SUP_SERV") {
				return oData.Data11 + ".xlsx";
			} else if (type === "EXEC_CST_ORG") {
				return oData.Data12 + ".xlsx";
			} else if (type === "EXEC_WRK_ORG") {
				return oData.Data13 + ".xlsx";
			}
		},
		createColumns: function (type, _this) {
			if (type === "EXEC_DE") {
				return [{
					label: "Item",
					property: "Item"
				}, {
					label: "YTD Actual",
					property: "Data1"
				}, {
					label: "YTD Plan",
					property: "Data2"
				}, {
					label: "Variance",
					property: "Data3"
				}, {
					label: "Variance (%)",
					property: "Data4"
				}];
			} else if (type === "EXEC_CC") {
				return [{
					label: "Month",
					property: "Actual"
				}, {
					label: "Actual(Prev Year)",
					property: "CostElement"
				}, {
					label: "Actual(Current Year)",
					property: "Period"
				},
				{
					label: "YTD(Prev Year)",
					property: "Data2"
				}, {
					label: "YTD(Current Year)",
					property: "Data3"
				}];
			} else if (type === "EXEC_SUP_SERV") {
				return [{
					label: "Item",
					property: "Component"
				}, {
					label: "YTD Actual",
					property: "PlanVal"
				}];
			} else if (type === "EXEC_CST_ORG") {
				return [{
					label: "Item",
					property: "Node"
				}, {
					label: "YTD Actual",
					property: "Value"
				}];
			} else if (type === "EXEC_WRK_ORG") {
				return [{
					label: "Item",
					property: "Node"
				}, {
					label: "YTD Actual",
					property: "Value"
				}];
			}
		}
	});
});
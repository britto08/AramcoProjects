sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/BusyIndicator",
	'sap/ui/export/Spreadsheet',
	"com/aramco/fion/fdbZFI_FION_FDB/utility/ExportExcelExecSummary"
], function (Controller, BusyIndicator, Spreadsheet, ExportExcelExecSummary) {
	"use strict";

	return Controller.extend("com.aramco.fion.fdbZFI_FION_FDB.services.dashboardService", {
		///// Changes by Hari ///////////////

		getVariance: function (actual, plan) {
			var variance;
			actual = parseFloat(actual);
			plan = parseFloat(plan);
			if (plan > 0) {
				variance = ((actual - plan) / (plan)) * 100;
			} else {
				variance = 0;
			}
			return variance;
		},

		getVarianceNumber: function (actual, plan) {
			var variance = "";
			actual = parseFloat(actual);
			plan = parseFloat(plan);
			variance = (actual - plan);
			if (isNaN(variance)) {
				variance = "0";
			}
			return variance;
		},

		/////////////////////////
		getDefaultService: function () {
			var oResult;
			this.showBusyIndicator(1000, 0);
			return new Promise(function (resolve, reject) {
				var oUrl = "/sap/opu/odata/sap/ZFI_FION_APP_DATA_SRV";
				var oModel = new sap.ui.model.odata.ODataModel(oUrl, true);
				oModel.read("/FionUserDetailsSet", {
					context: null,
					urlParameters: null,
					async: false,
					success: function (oData, oResponse) {
						if (oData.results.length !== 0) {
							oResult = oData.results;
						} else {
							oResult = [];
						}
						//return oResult;
						resolve(oResult);
					},
					error: function (a) {
						oResult = [];
						resolve(oResult);
						sap.m.MessageToast.show("Unexpected error occured! Please try again later");
						return false;
					}
				});
			});
		},
		postEditData: function (oEntry) {
			var oResult;
			this.showBusyIndicator(1000, 0);
			return new Promise(function (resolve, reject) {
				var oUrl = "/sap/opu/odata/sap/ZFI_FINANCE_DB_CONFIG_MAINT_SRV";
				var oModel = new sap.ui.model.odata.ODataModel(oUrl, true);
				oModel.create("/Maintain_dataSet", oEntry, null,
					function (oData, oResponse) {
						try {
							oResult = oData;
							resolve(oResult);
						} catch (e) {
							sap.m.MessageToast.show("Unexpected error occured! Please try again later");
							return false;
						}
					});
			});
		},
		getMaintRecords: function (oView, TableType) {
			var oResult;
			var aa = "";
			this.showBusyIndicator(1000, 0);
			return new Promise(function (resolve, reject) {
				var oUrl = "/sap/opu/odata/sap/ZFI_FINANCE_DB_CONFIG_MAINT_SRV";
				var oModel = new sap.ui.model.odata.ODataModel(oUrl, true);
				oModel.read("/Maintain_dataSet?$filter=Zview eq '" + oView + "' and Zcomponent eq '" + aa + "' and Zcocelgr eq '" + aa +
					"' and Type eq '" + TableType + "'", {
						context: null,
						urlParameters: null,
						async: false,
						success: function (oData, oResponse) {
							if (oData.results.length !== 0) {
								//s = _this.loadHierarchy(oData.results);
								oResult = oData.results;
							} else {
								oResult = [];
							}
							//return oResult;
							resolve(oResult);
						},
						error: function (a) {
							/*oJsonModel.setData({
								"Items": {
									children: []
								}
							});*/
							sap.m.MessageToast.show("Unexpected error occured! Please try again later");
							return false;
						}
					});
			});
		},
		getCostCentreHier: function (M, Y) {
			var oResult, period, Type = "CC";
			period = M + Y;
			this.showBusyIndicator(1000, 0);
			return new Promise(function (resolve, reject) {
				//var oUrl = "/sap/opu/odata/sap/ZMIS_BL_NAR_CC_HIER_SRV";
				var oUrl = "/sap/opu/odata/sap/ZFI_FION_APP_DATA_SRV";
				var oModel = new sap.ui.model.odata.ODataModel(oUrl, true);
				//oModel.read("/ZMIS_BL_NAR_CC_HIER(A0P_FYEAR='" + Y + "',ZSEM_MYP='" + M + "')/Results", {
				oModel.read("Main_HierSet?$filter=Period eq'" + period + "' and Type eq'" + Type + "'", {
					context: null,
					urlParameters: null,
					async: false,
					success: function (oData, oResponse) {
						if (oData.results.length !== 0) {
							//s = _this.loadHierarchy(oData.results);
							oResult = oData.results;
						} else {
							oResult = [];
						}
						//return oResult;
						resolve(oResult);
					},
					error: function (a) {
						/*oJsonModel.setData({
							"Items": {
								children: []
							}
						});*/
						oResult = [];
						resolve(oResult);
						sap.m.MessageToast.show("Unexpected error occured! Please try again later");
						return false;
					}
				});
			});
		},
		getExecutiveSummery: function (period, costcenter, subnodes, oKey) {
			var oResult;
			this.showBusyIndicator(1300, 0);
			return new Promise(function (resolve, reject) {
				var oUrl = "/sap/opu/odata/SAP/ZFI_FION_APP_DATA_SRV";
				var oModel = new sap.ui.model.odata.ODataModel(oUrl, true);
				oModel.read("/FionHeaderSet?$filter=Period eq '" + period + "' and Node eq '" + costcenter + "' and SubNodes eq '" + subnodes +
					"' and ViewName eq '" + oKey +
					"'&$expand=NavHeadertoItem1,NavHeadertoItem2,NavHeadertoItem3,NavHeadertoItem4,NavHeadertoItem5,NavHeadertoItem6,NavHeadertoItem7,NavHeadertoItem8", {
						context: null,
						urlParameters: null,
						async: false,
						success: function (oData, oResponse) {
							if (oData.results.length !== 0) {
								//s = _this.loadHierarchy(oData.results);
								oResult = oData.results;
							} else {
								oResult = [];
							}
							//return oResult;
							resolve(oResult);
						},
						error: function (a) {
							/*oJsonModel.setData({
								"Items": {
									children: []
								}
							});*/
							sap.m.MessageToast.show("Unexpected error occured! Please try again later");
							return false;
						}
					});
			});
		},
		loadHierarchy: function (nodesIn) {
			var nodes = [];
			var nodeMap = {};
			if (nodesIn) {
				var nodeOut, parentId;
				for (var i = 0; i < nodesIn.length; i++) {
					var nodeIn = nodesIn[i];
					nodeOut = {
						id: nodeIn.Data7,
						text: nodeIn.Data14,
						//costcentre: nodeIn.Data10,
						costcentre: nodeIn.Data9,
						costcentre_1: nodeIn.Data10,
						children: []
					};
					parentId = nodeIn.Data12;
					if (parentId && parentId.length > 0 && parentId !== "00000000") {
						var parent = nodeMap[nodeIn.Data12];
						if (parent) {
							parent.children.push(nodeOut);
						}
					} else {
						nodes.push(nodeOut);
					}
					nodeMap[nodeOut.id] = nodeOut;
				}
			}
			return nodes;
		},
		setDefaultCardsData: function (_this) {
			_this.getView().byId("id_cc_actual").setText("0.0");
			_this.getView().byId("id_cc_plan").setText("0.0");
			_this.getView().byId("id_cc_var").setText("(" + "0%" + ")");
			_this.getView().byId("id_wf_actual").setText("0.0");
			_this.getView().byId("id_wf_plan").setText("0.0");
			_this.getView().byId("id_wf_var").setText("(" + "0%" + ")");
			_this.getView().byId("id_ss_actual").setText("0.0");
			_this.getView().byId("id_ss_plan").setText("0.0");
			_this.getView().byId("id_ss_var").setText("(" + "0%" + ")");
			_this.getView().byId("id_dep_actual").setText("0.0");
			_this.getView().byId("id_dep_plan").setText("0.0");
			_this.getView().byId("id_dep_var").setText("(" + "0%" + ")");
		},
		getColor: function (oVal) {
			if (oVal === "#00843D") {
				return "contentGreen";
			} else if (oVal === "#FF3300") {
				return "contentRed";
			}
		},
		setCardsData: function (data, _this) {
			for (var i in data) {
				if (data[i].Component === "ES_SCORE_CARD_1") {
					var oActual_1 = _this.getAmountFormat(data[i].Actual, _this);
					_this.getView().byId("id_cc_actual").setText(oActual_1);
					var oPlan_1 = _this.getAmountFormat(data[i].PlanVal, _this);
					_this.getView().byId("id_cc_plan").setText(oPlan_1);
					var class_1 = _this.getColor(data[i].ViewName);
					_this.getView().byId("id_cc_var").addStyleClass(class_1);
					_this.getView().byId("id_cc_var").setText("(" + _this.onAmountValidation(data[i].Variance) + "%" + ")");
				} else if (data[i].Component === "ES_SCORE_CARD_2") {
					var oActual_2 = _this.getAmountFormat(data[i].Actual, _this);
					_this.getView().byId("id_wf_actual").setText(oActual_2);
					var oPlan_2 = _this.getAmountFormat(data[i].PlanVal, _this);
					_this.getView().byId("id_wf_plan").setText(oPlan_2);
					var class_2 = _this.getColor(data[i].ViewName);
					_this.getView().byId("id_wf_var").addStyleClass(class_2);
					_this.getView().byId("id_wf_var").setText("(" + _this.onAmountValidation(data[i].Variance) + "%" + ")");
				} else if (data[i].Component === "ES_SCORE_CARD_3") {
					var oActual_3 = _this.getAmountFormat(data[i].Actual, _this);
					_this.getView().byId("id_ss_actual").setText(oActual_3);
					var oPlan_3 = _this.getAmountFormat(data[i].PlanVal, _this);
					_this.getView().byId("id_ss_plan").setText(oPlan_3);
					var class_3 = _this.getColor(data[i].ViewName);
					_this.getView().byId("id_ss_var").addStyleClass(class_3);
					_this.getView().byId("id_ss_var").setText("(" + _this.onAmountValidation(data[i].Variance) + "%" + ")");
				} else if (data[i].Component === "ES_SCORE_CARD_4") {
					var oActual_4 = _this.getAmountFormat(data[i].Actual, _this);
					_this.getView().byId("id_dep_actual").setText(oActual_4);
					var oPlan_4 = _this.getAmountFormat(data[i].PlanVal, _this);
					_this.getView().byId("id_dep_plan").setText(oPlan_4);
					var class_4 = _this.getColor(data[i].ViewName);
					_this.getView().byId("id_dep_var").addStyleClass(class_4);
					_this.getView().byId("id_dep_var").setText("(" + _this.onAmountValidation(data[i].Variance) + "%" + ")");
				}
			}
		},
		setDefualtContCards: function (_this) {
			_this.getView().byId("id_con_card_actual").setText("0.0");
			_this.getView().byId("id_con_card_actual_1").setText("0.0");
			_this.getView().byId("id_con_card_actual_2").setText("0.0");
			_this.getView().byId("id_con_card_actual_3").setText("0.0");
			_this.getView().byId("id_con_card_plan").setText("0.0");
			_this.getView().byId("id_con_card_plan_1").setText("0.0");
			_this.getView().byId("id_con_card_plan_2").setText("0.0");
			_this.getView().byId("id_con_card_plan_3").setText("0.0");
			_this.getView().byId("id_con_card_var_1").setText("(0.0)");
			_this.getView().byId("id_con_card_var").setText("(0.0)");
			_this.getView().byId("id_con_card_var_2").setText("(0.0)");
			_this.getView().byId("id_con_card_var_3").setText("(0.0)");
		},
		setContCostCards: function (data, _this) {
			for (var i in data) {
				if (data[i].Data4 === "CC_DC_COST_1") { //Labor
					var oActual_1 = _this.getAmountFormat(data[i].Data1, _this);
					_this.getView().byId("id_con_card_actual").setText(oActual_1);
					var oPlan_1 = _this.getAmountFormat(data[i].Data2, _this);
					_this.getView().byId("id_con_card_plan").setText(oPlan_1);
					_this.getView().byId("id_con_card_var").setText("(" + _this.onAmountValidation(data[i].Data3) + "%" + ")");
				} else if (data[i].Data4 === "CC_DC_COST_2") { //Material
					var oActual_2 = _this.getAmountFormat(data[i].Data1, _this);
					_this.getView().byId("id_con_card_actual_1").setText(oActual_2);
					var oPlan_2 = _this.getAmountFormat(data[i].Data2, _this);
					_this.getView().byId("id_con_card_plan_1").setText(oPlan_2);
					_this.getView().byId("id_con_card_var_1").setText("(" + _this.onAmountValidation(data[i].Data3) + "%" + ")");
				} else if (data[i].Data4 === "CC_DC_COST_3") { //Service
					var oActual_3 = _this.getAmountFormat(data[i].Data1, _this);
					_this.getView().byId("id_con_card_actual_2").setText(oActual_3);
					var oPlan_3 = _this.getAmountFormat(data[i].Data2, _this);
					_this.getView().byId("id_con_card_plan_2").setText(oPlan_3);
					_this.getView().byId("id_con_card_var_2").setText("(" + _this.onAmountValidation(data[i].Data3) + "%" + ")");
				} else if (data[i].Data4 === "CC_DC_COST_4") { //Power
					var oActual_4 = _this.getAmountFormat(data[i].Data1, _this);
					_this.getView().byId("id_con_card_actual_3").setText(oActual_4);
					var oPlan_4 = _this.getAmountFormat(data[i].Data2, _this);
					_this.getView().byId("id_con_card_plan_3").setText(oPlan_4);
					_this.getView().byId("id_con_card_var_3").setText("(" + _this.onAmountValidation(data[i].Data3) + "%" + ")");
				}
			}
		},
		getFinalAmountFormat: function (oVal) {
			var oVal_1;
			oVal_1 = String(oVal);
			if (oVal_1 !== undefined) {
				if (Number(oVal) > 999 && (Number(oVal) < 1000000)) {
					oVal_1 = (Number(oVal) / 1000).toFixed(1);
					oVal_1 = this.onAmountValidation(oVal_1);
					oVal_1 = oVal_1 + "K";
					return oVal_1;
				} else if (Number(oVal) > 1000000) {
					oVal_1 = (Number(oVal) / 1000000).toFixed(1);
					oVal_1 = this.onAmountValidation(oVal_1);
					oVal_1 = oVal_1 + "M";
					return oVal_1;
				} else if (Number(oVal) < 900) {
					oVal_1 = this.onAmountValidation(oVal_1);
					oVal_1 = oVal_1;
					return oVal_1;
				}
			}
		},
		getAmountFormat: function (oVal, _this) {
			var oVal_1;
			oVal_1 = String(oVal);
			if (oVal_1 !== undefined) {
				if (Number(oVal) > 999 && (Number(oVal) < 1000000)) {
					oVal_1 = (Number(oVal) / 1000).toFixed(1);
					oVal_1 = _this.onAmountValidation(oVal_1);
					oVal_1 = oVal_1 + "K";
					return oVal_1;
				} else if (Number(oVal) > 1000000) {
					oVal_1 = (Number(oVal) / 1000000).toFixed(1);
					oVal_1 = _this.onAmountValidation(oVal_1);
					oVal_1 = oVal_1 + "M";
					return oVal_1;
				} else if (Number(oVal) < 900) {
					oVal_1 = _this.onAmountValidation(oVal_1);
					oVal_1 = oVal_1;
					return oVal_1;
				}
			}
		},
		onAmountValidation: function (oVal) {
			if (oVal !== undefined && oVal !== null) {
				if (oVal.includes("-") === true) {
					oVal = oVal.substr(0, oVal.length - 1);
					oVal = Number(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0
					});
					oVal = "-" + oVal;
				} else {
					oVal = Number(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0
					});
				}
				return oVal;
			}
		},
		showBusyIndicator: function (iDuration, iDelay) {
			BusyIndicator.show(iDelay);
			if (iDuration && iDuration > 0) {
				if (this._sTimeoutId) {
					clearTimeout(this._sTimeoutId);
					this._sTimeoutId = null;
				}
				this._sTimeoutId = setTimeout(function () {
					BusyIndicator.hide();
				}.bind(this), iDuration);
			}
		},
		getSubType: function (oKey) {
			var a = [],
				b = {};
			if (oKey === "EXEC_SUMMARY") {
				b.Key = "C_COST";
				b.Text = "CONTROLLABLE COST TREND";
				a.push(b);
				b = {};
				b.Key = "ES_DIREXP";
				b.Text = "DIRECT EXPENDITURE";
				a.push(b);
				b = {};
				b.Key = "ES_SCORE_CARD_1";
				b.Text = "CONTROLLABLE COST SCORE CARD";
				a.push(b);
				b = {};
				b.Key = "ES_SCORE_CARD_2";
				b.Text = "CONTROLLABLE COST SCORE CARD";
				a.push(b);
				b = {};
				b.Key = "ES_SCORE_CARD_3";
				b.Text = "CONTROLLABLE COST SCORE CARD";
				a.push(b);
				b = {};
				b.Key = "ES_SCORE_CARD_4";
				b.Text = "CONTROLLABLE COST SCORE CARD";
				a.push(b);
				b = {};
				b.Key = "ORG_CLA";
				b.Text = "COST BY ORG";
				a.push(b);
				b = {};
				b.Key = "WF_ORG_CLA";
				b.Text = "WORKFORCE BY ORG";
				a.push(b);
				b = {};
				b.Key = "SS_TOP5";
				b.Text = "SUPPORT SERVICES TOP5";
				a.push(b);
			} else if (oKey === "CONT_COST") {
				b.Key = "CC_CC_ORG";
				b.Text = "CONTROLLABLE COST BY ORG";
				a.push(b);
				b = {};
				b.Key = "CC_DC_COST_1";
				b.Text = "DIRECT CONTROLLABLE";
				a.push(b);
				b = {};
				b.Key = "CC_DC_COST_2";
				b.Text = "DIRECT CONTROLLABLE";
				a.push(b);
				b = {};
				b.Key = "CC_DC_COST_3";
				b.Text = "DIRECT CONTROLLABLE";
				a.push(b);
				b = {};
				b.Key = "CC_DC_COST_4";
				b.Text = "DIRECT CONTROLLABLE";
				a.push(b);
				b = {};
				b.Key = "CC_DC_ORG";
				b.Text = "DIRECT CONTROLLABLE_COST_BY_ORG";
				a.push(b);
				b = {};
				b.Key = "CC_SERV_IN_REC";
				b.Text = "SERVICE INCOME COST RECOVERY";
				a.push(b);
				b = {};
				b.Key = "CC_RECOV_CAP";
				b.Text = "RECOVERY TO CAPEXT";
				a.push(b);
				b = {};
				b.Key = "CC_DEPRECIATION";
				b.Text = "DEPRECIATION";
				a.push(b);
				b = {};
				b.Key = "CC_GEO_COST";
				b.Text = "GEOLOGICL AND GEOPHYSICAL COST";
				a.push(b);
			} else if (oKey === "WORKFORCE") {
				b.Key = "WF_BY_ORG";
				b.Text = "WORKFORCE BY ORG";
				a.push(b);
				b = {};
				b.Key = "WF_EMP";
				b.Text = "EMPLOYEE";
				a.push(b);
				b = {};
				b.Key = "WF_SM1";
				b.Text = "SAUDI BY GRADE";
				a.push(b);
				b = {};
				b.Key = "WF_SM2";
				b.Text = "EXPAT BY GRADE";
				a.push(b);
				b = {};
				b.Key = "WF_SM3";
				b.Text = "SAUDIS BY GRADE(SMP)";
				a.push(b);
				b = {};
				b.Key = "WF_SM4";
				b.Text = "EXPAT BY GRADE(SMP)";
				a.push(b);
				b = {};
				b.Key = "WF_NATIONALITY";
				b.Text = "WORKFORCE By NATIONALITY";
				a.push(b);
			} else if (oKey === "SUPPORT_SRV") {
				b.Key = "SS_SUP_SRV_ORG";
				b.Text = "SUPPORT SERVICES BY ORG";
				a.push(b);
				b = {};
				b.Key = "SS_SUP_SRV_ORG";
				b.Text = "SUPPORT SERVICES BY ORG";
				a.push(b);
				b = {};
				b.Key = "SS_SUP_SRV_TRD";
				b.Text = "SUPPORT SERVICES TREND";
				a.push(b);
			}
			return a;
		},
		hasItems: function (oVal) {
			var oItem = [oVal];
			var Items = ["ES_SCORE_CARD_1", "ES_SCORE_CARD_2", "ES_SCORE_CARD_3", "ES_SCORE_CARD_4", "CC_DC_COST_1", "CC_DC_COST_2",
				"CC_DC_COST_3", "CC_DC_COST_4",
				"CC_DEPRECIATION", "CC_GEO_COST"
			];
			var IsAdded = Items.filter(function (itm) {
				return oItem.indexOf(itm) > -1;
			});
			if (IsAdded.length !== 0) {
				return "1";
			} else {
				return "0";
			}
		},
		getComponentIds: function (oKey) {
			var a = [],
				b = {};
			if (oKey === "ES_SCORE_CARD") {
				b.Key = "CONTROLLABLE COST SCORE CARD";
				b.Text = "CONTROLLABLE COST TREND";
				a.push(b);
				b = {};
				b.Key = "WORKFORCE";
				b.Text = "DIRECT EXPENDITURE";
				a.push(b);
				b = {};
				b.Key = "SUPPORT SERVICES";
				b.Text = "CONTROLLABLE COST SCORE CARD";
				a.push(b);
				b = {};
				b.Key = "DEPRECIATION";
				b.Text = "COST BY ORG AND WORKFORCE BY ORG";
				a.push(b);
			} else if (oKey === "ES_DIREXP") {
				b.Key = "LABOR";
				a.push(b);
				b = {};
				b.Key = "TOTAL";
				a.push(b);
				b = {};
				b.Key = "MATERIAL";
				a.push(b);
				b = {};
				b.Key = "SERVICE";
				a.push(b);
				b = {};
				b.Key = "POWER";
				a.push(b);
			}
			return a;
		},
		setContCostOrgTable: function (data, _this) {
			var uniqueItems = [];
			$.each(data, function (j, el) {
				if (_this.inArray_1(uniqueItems, el) === false) {
					uniqueItems.push(el);
				}
			}.bind(_this));
			var newArray = [],
				obj = {};
			for (var k in uniqueItems) {
				var f = uniqueItems[k].CostElement;
				var newCollection = data.filter(function (el) {
					return el.CostElement === f;
				});
				for (var z in newCollection) {
					obj.Item = newCollection[z].CostElement;
					if (z === "0") {
						obj.Data1 = newCollection[z].Actual;
						obj.Data5 = newCollection[z].Data1;
					} else {
						obj.Data2 = newCollection[z].Actual;
						obj.Data6 = newCollection[z].Data1;
					}
				}
				obj.Data3 = this.getVariance(obj.Data1, obj.Data2);
				obj.Data4 = this.getVarianceNumber(obj.Data1, obj.Data2);
				newArray.push(obj), obj = {};
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": newArray
				});
				_this.getView().byId("id_tablecont_cost_org").setModel(oJsonModel);
			}
		},
		inArray_1: function (array, el) {
			var find = false;
			$.each(array, function (index, value) {
				if (el.CostElement === value.CostElement) {
					find = true;
					return false;
				}
			});
			return find;
		},
		setSupServTab: function (data, _this) {
			var uniqueItems = [];
			$.each(data, function (j, el) {
				if (_this.inArray_2(uniqueItems, el) === false) {
					uniqueItems.push(el);
				}
			}.bind(_this));
			var newArray = [],
				obj = {};
			for (var k in uniqueItems) {
				var f = uniqueItems[k].CostElement;
				var newCollection = data.filter(function (el) {
					return el.CostElement === f;
				});
				for (var z in newCollection) {
					obj.Item = newCollection[z].CostElement;
					if (z === "0") {
						obj.Data1 = newCollection[z].Actual;
					} else {
						obj.Data2 = newCollection[z].Actual;
					}
				}
				obj.Data3 = this.getVariance(obj.Data1, obj.Data2);
				obj.Data4 = this.getVarianceNumber(obj.Data1, obj.Data2);
				newArray.push(obj), obj = {};
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": newArray
				});
				_this.getView().byId("id_table_supserv").setModel(oJsonModel);
			}
		},
		inArray_2: function (array, el) {
			var find = false;
			$.each(array, function (index, value) {
				if (el.CostElement === value.CostElement) {
					find = true;
					return false;
				}
			});
			return find;
		},
		setWorkforceOrgTab: function (data, _this) {
			var uniqueItems = [];
			$.each(data, function (j, el) {
				if (_this.inArray_3(uniqueItems, el) === false) {
					uniqueItems.push(el);
				}
			}.bind(_this));
			var newArray = [],
				obj = {};
			for (var k in uniqueItems) {
				var f = uniqueItems[k].CostElement;
				var newCollection = data.filter(function (el) {
					return el.CostElement === f;
				});
				for (var z in newCollection) {
					obj.Item = newCollection[z].CostElement;
					if (z === "0") {
						obj.Data1 = newCollection[z].Actual;
					} else {
						obj.Data2 = newCollection[z].Actual;
					}
				}
				obj.Data3 = this.getVariance(obj.Data1, obj.Data2);
				obj.Data4 = this.getVarianceNumber(obj.Data1, obj.Data2);
				newArray.push(obj), obj = {};
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": newArray
				});
				_this.getView().byId("id_tab_workforce_org").setModel(oJsonModel);
			}
		},
		inArray_3: function (array, el) {
			var find = false;
			$.each(array, function (index, value) {
				if (el.CostElement === value.CostElement) {
					find = true;
					return false;
				}
			});
			return find;
		},
		setSaudisbyGradeTab: function (data, _this) {
			var uniqueItems = [];
			$.each(data, function (j, el) {
				if (_this.inArray_2(uniqueItems, el) === false) {
					uniqueItems.push(el);
				}
			}.bind(_this));
			var newArray = [],
				obj = {};
			for (var k in uniqueItems) {
				var f = uniqueItems[k].CostElement;
				var newCollection = data.filter(function (el) {
					return el.CostElement === f;
				});
				for (var z in newCollection) {
					obj.Item = newCollection[z].CostElement;
					if (z === "0") {
						obj.Data1 = newCollection[z].PlanVal;
					} else {
						obj.Data2 = newCollection[z].PlanVal;
					}
				}
				obj.Data3 = this.getVariance(obj.Data1, obj.Data2);
				obj.Data4 = this.getVarianceNumber(obj.Data1, obj.Data2);
				newArray.push(obj), obj = {};
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": newArray
				});
				_this.getView().byId("id_tab_saudis_by_grade").setModel(oJsonModel);
			}
		},
		setExpatbyGradeTab: function (data, _this) {
			var uniqueItems = [];
			$.each(data, function (j, el) {
				if (_this.inArray_2(uniqueItems, el) === false) {
					uniqueItems.push(el);
				}
			}.bind(_this));
			var newArray = [],
				obj = {};
			for (var k in uniqueItems) {
				var f = uniqueItems[k].CostElement;
				var newCollection = data.filter(function (el) {
					return el.CostElement === f;
				});
				for (var z in newCollection) {
					obj.Item = newCollection[z].CostElement;
					if (z === "0") {
						obj.Data1 = newCollection[z].Actual;
					} else {
						obj.Data2 = newCollection[z].Actual;
					}
				}
				obj.Data3 = this.getVariance(obj.Data1, obj.Data2);
				obj.Data4 = this.getVarianceNumber(obj.Data1, obj.Data2);
				newArray.push(obj), obj = {};
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": newArray
				});
				_this.getView().byId("id_tab_expat_by_grade").setModel(oJsonModel);
			}
		},
		setSMPSaudibyGrade: function (data, _this) {
			var uniqueItems = [];
			$.each(data, function (j, el) {
				if (_this.inArray_4(uniqueItems, el) === false) {
					uniqueItems.push(el);
				}
			}.bind(_this));
			var newArray = [],
				obj = {};
			for (var k in uniqueItems) {
				var f = uniqueItems[k].Node;
				var newCollection = data.filter(function (el) {
					return el.Node === f;
				});
				for (var z in newCollection) {
					obj.Item = newCollection[z].Node;
					if (z === "0") {
						obj.Data1 = newCollection[z].Value;
					} else {
						obj.Data2 = newCollection[z].Value;
					}
				}
				obj.Data3 = this.getVariance(obj.Data1, obj.Data2);
				obj.Data4 = this.getVarianceNumber(obj.Data1, obj.Data2);
				newArray.push(obj), obj = {};
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": newArray
				});
				_this.getView().byId("id_tab_smp_saudi_by_grade").setModel(oJsonModel);
			}
		},
		inArray_4: function (array, el) {
			var find = false;
			$.each(array, function (index, value) {
				if (el.Node === value.Node) {
					find = true;
					return false;
				}
			});
			return find;
		},
		setSMPExaptbyGrade: function (data, _this) {
			var uniqueItems = [];
			$.each(data, function (j, el) {
				if (_this.inArray_4(uniqueItems, el) === false) {
					uniqueItems.push(el);
				}
			}.bind(_this));
			var newArray = [],
				obj = {};
			for (var k in uniqueItems) {
				var f = uniqueItems[k].Node;
				var newCollection = data.filter(function (el) {
					return el.Node === f;
				});
				for (var z in newCollection) {
					obj.Item = newCollection[z].Node;
					if (z === "0") {
						obj.Data1 = newCollection[z].Value;
					} else {
						obj.Data2 = newCollection[z].Value;
					}
				}
				obj.Data3 = this.getVariance(obj.Data1, obj.Data2);
				obj.Data4 = this.getVarianceNumber(obj.Data1, obj.Data2);
				newArray.push(obj), obj = {};
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": newArray
				});
				_this.getView().byId("id_tab_smp_expat_by_grade").setModel(oJsonModel);
			}
		},
		setClearModel: function (_this) {
			var oJsonModel = new sap.ui.model.json.JSONModel();
			oJsonModel.setData({
				"Items": []
			});
			_this.getView().byId("id_tab_workforce_org").setModel(oJsonModel);
			_this.getView().byId("id_tab_saudis_by_grade").setModel(oJsonModel);
			_this.getView().byId("id_tab_expat_by_grade").setModel(oJsonModel);
			_this.getView().byId("id_tab_smp_saudi_by_grade").setModel(oJsonModel);
			_this.getView().byId("id_tab_smp_expat_by_grade").setModel(oJsonModel);
			_this.getView().byId("id_table_water_fall").setModel(oJsonModel);
			_this.getView().byId("id_tablecont_cost_org").setModel(oJsonModel);
			_this.getView().byId("id_table_supserv").setModel(oJsonModel);
		},
		onExport: function (oEvent) {
			var _this = this,
				dataSource, fileName, oColumns;
			var oType = oEvent.getSource().getCustomData()[0].getValue();
			if (oType === "EXEC_DE" || oType === "EXEC_CC" || oType === "EXEC_SUP_SERV" || oType === "EXEC_CST_ORG" || oType === "EXEC_WRK_ORG") {
				dataSource = this.ExportExcelExecSummary.getDataSource(oType, _this);
				fileName = this.ExportExcelExecSummary.getFileName(oType, _this);
				oColumns = this.ExportExcelExecSummary.createColumns(oType, _this);
			} else if (oType === "CC_BY_ORG" || oType === "CC_D_BY_ORG" || oType === "CC_OV_TIME" || oType === "CC_REC_CAPEX" || oType ===
				"CC_REC_CAPEX" || oType === "CC_SERV_INC") {
				dataSource = this.ExcelControllableCost.getDataSource(oType, _this);
				fileName = this.ExcelControllableCost.getFileName(oType, _this);
				oColumns = this.ExcelControllableCost.createColumns(oType, _this);
			} else if (oType === "WF_ORG" || oType === "WF_NAT" || oType === "WF_SA_GRADE" || oType === "WF_EXPAT_GRADE" || oType ===
				"WF_SMP_SA_GRADE" || oType === "WF_SMP_EXPAT_GRADE") {
				dataSource = this.ExcelWorkforce.getDataSource(oType, _this);
				fileName = this.ExcelWorkforce.getFileName(oType, _this);
				oColumns = this.ExcelWorkforce.createColumns(oType, _this);
			}
			new Spreadsheet({
				workbook: {
					columns: oColumns
				},
				dataSource: dataSource,
				fileName: fileName
			}).build();
		}
	});
});
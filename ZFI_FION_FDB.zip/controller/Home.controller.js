sap.ui.define([
	"sap/ui/core/mvc/Controller",
	'com/aramco/fion/fdbZFI_FION_FDB/services/dashboardService',
	'sap/ui/core/Fragment',
	"sap/m/MessageBox",
	"com/aramco/fion/fdbZFI_FION_FDB/utility/ExportExcelExecSummary",
	"com/aramco/fion/fdbZFI_FION_FDB/utility/ExcelExport/ControllableCost",
	"com/aramco/fion/fdbZFI_FION_FDB/utility/ExcelExport/Workforce"
], function (Controller, DashboardService, Fragment, MessageBox, ExportExcelExecSummary, ExcelControllableCost, ExcelWorkforce) {
	"use strict";
	var globalData;
	var exeSumChartValue;
	var ccByOrgValue;
	var overTimeValue;
	var CCValue;
	var sstValue;
	return DashboardService.extend("com.aramco.fion.fdbZFI_FION_FDB.controller.Home", {
		//////Hari changes ///////////
		getVariance: function (actual, plan) {
			var variance;
			if (actual)
				actual = actual.replace(/\,/g, '');
			if (plan)
				plan = plan.replace(/\,/g, '');
			actual = parseFloat(actual);
			plan = parseFloat(plan);
			if (plan > 0) {
				variance = ((actual - plan) / (plan)) * 100;
			} else {
				variance = 0;
			}
			if (isNaN(variance)) {
				variance = "0";
			}
			return variance;
		},

		getVarianceNumber: function (actual, plan) {
			var variance = "";
			if (actual)
				actual = actual.replace(/\,/g, '');
			if (plan)
				plan = plan.replace(/\,/g, '');
			actual = parseFloat(actual);
			plan = parseFloat(plan);
			variance = (actual - plan);
			if (isNaN(variance)) {
				variance = "0";
			}
			return parseInt(variance);
		},

		getColor: function (oVal) {
			if (Number(oVal) > 7) { /*"#00843D"*/
				return "Error";
			} else if (Number(oVal) > 3) { /*"#FF3300"*/
				return "Warning";
			} else { /*"#FFA500"*/
				return "Success";
			}
		},

		OTVarPColor: function (a, b) {
			var oVal = this.OTVarP(a, b);
			console.log(a, b, oVal,"oVal");
			if (Number(oVal) > 7) { /*"#00843D"*/
				return "Error";
			} else if (Number(oVal) > 3) { /*"#FF3300"*/
				return "Warning";
			} else { /*"#FFA500"*/
				return "Success";
			}
		},

		OTVar: function (a, b) {
			var oVal = this.getVarianceNumber(a, b);
			if (oVal) {
				oVal = oVal.toString();
				if (oVal !== null && oVal !== "" && oVal !== undefined) {
					if (oVal.includes("-") === true) {
						if (oVal.substr(0, 1) === "-") {
							oVal = oVal.substr(1, oVal.length);
						} else {
							oVal = oVal.substr(0, oVal.length - 1);
						}
						oVal = Number(oVal);
						//oVal = Math.round(oVal);
						oVal = oVal.toLocaleString('en-us', {
							minimumFractionDigits: 0,
							maximumFractionDigits: 2
						});
						oVal = "( " + oVal + " )";
					} else {
						oVal = Number(oVal);
						//oVal = Math.round(oVal);
						oVal = oVal.toLocaleString('en-us', {
							minimumFractionDigits: 0,
							maximumFractionDigits: 2
						});
					}
				}
			}

			return oVal;
		},

		OTVarP: function (a, b) {
			var oVal = this.getVariance(a, b);
			if (oVal) {
				oVal = oVal.toString();
				if (oVal !== null && oVal !== "" && oVal !== undefined) {
					if (oVal.includes("-") === true) {
						if (oVal.substr(0, 1) === "-") {
							oVal = oVal.substr(1, oVal.length);
						} else {
							oVal = oVal.substr(0, oVal.length - 1);
						}
						oVal = Number(oVal);
						//oVal = Math.round(oVal);
						oVal = oVal.toLocaleString('en-us', {
							minimumFractionDigits: 0,
							maximumFractionDigits: 2
						});
						oVal = "( " + oVal + " )";
					} else {
						oVal = Number(oVal);
						//oVal = Math.round(oVal);
						oVal = oVal.toLocaleString('en-us', {
							minimumFractionDigits: 0,
							maximumFractionDigits: 2
						});
					}
				}
			}

			return oVal;
		},

		onAmountFormatVar: function (oVal) {
			if (oVal) {
				oVal = oVal.toString();
			}
			if (oVal !== null && oVal !== "" && oVal !== undefined) {
				if (oVal.includes("-") === true) {
					if (oVal.substr(0, 1) === "-") {
						oVal = oVal.substr(1, oVal.length);
					} else {
						oVal = oVal.substr(0, oVal.length - 1);
					}
					oVal = Number(oVal);
					//oVal = Math.round(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0,
						maximumFractionDigits: 2
					});
					oVal = "( " + oVal + " )";
				} else {
					oVal = Number(oVal);
					//oVal = Math.round(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0,
						maximumFractionDigits: 2
					});
				}
			}
			return oVal;
		},

		///////////////////////
		onInit: function () {
			this.ExportExcelExecSummary = new ExportExcelExecSummary(this);
			this.ExcelControllableCost = new ExcelControllableCost(this);
			this.ExcelWorkforce = new ExcelWorkforce(this);
			this.selectedKey = "EXEC_SUMMARY";
			var oTabcontainer = this.getView().byId("icontabbar");
			this.exeSumChartValue = "YTD";
			this.ccByOrgValue = "YTD";
			this.overTimeValue = "YTD";
			this.CCValue = "YTD";
			this.sstValue = "YTD";
			oTabcontainer.addEventDelegate({
				onAfterRendering: function () {
					var oTabStrip = this.getAggregation("_tabStrip");
					var oItems = oTabStrip.getItems();
					for (var i = 0; i < oItems.length; i++) {
						var oCloseButton = oItems[i].getAggregation("_closeButton");
						oCloseButton.setVisible(false);
					}
				}
			}, oTabcontainer);
		},
		onAfterRendering: function () {
			var _this = this,
				oSticky = ["ColumnHeaders"];
			//this.getView().byId("icontabbar").setSelectedKey("EXEC_SUMMARY");
			this.getDefaultService().then(function (result) {
				var a = result;
				if (a[0].MessageId === "S") {
					var oDate = a[0].Period;
					var d = String(a[0].Period.substr(3, 7)) + String(a[0].Period.substr(1, 2)) + "01";
					_this.getView().byId("date").setValue(d);
					_this.onDateChange();
					_this.getView().byId("userName").setText("Welcome " + a[0].UserName + "," + " " + "Last Login" + " " + a[0].LastLogin);
					if (a[0].Data2 === "X") {
						_this.getView().byId("adminBtn").setVisible(true);
						_this.getView().byId("homeBtn").setVisible(true);
					}
				}
			});
			this.getView().byId("supportserv_table").setSticky(oSticky);
			this.getView().byId("table_maint").setSticky(oSticky);
			this.getView().byId("text_table_maint").setSticky(oSticky);
		},

		onHomePress: function () {
			this.getView().byId("tableMaintaintence").setVisible(false);
			this.getView().byId("tabs").setVisible(true);
		},

		onAdmPress: function () {
			this.getView().byId("tableMaintaintence").setVisible(true);
			this.getView().byId("tabs").setVisible(false);
		},

		onCardTitle: function (oVal) {
			if (oVal !== "" && oVal !== undefined) {
				return "(" + oVal + ")";
			}
		},
		onDateChange: function (oEvent) {
			this.getView().byId("icontabbar").setVisible(true);
			var oDate = this.getView().byId("date").getDateValue();
			var oMonth = oDate.getMonth() + 1;
			if (oMonth < 10) {
				oMonth = "0" + oMonth;
			}
			oMonth = "0" + oMonth;
			var oYear = oDate.getFullYear();
			//this.getCostCenter(oMonth, oYear);
			var oView = this.getView();
			//this.costcenter = sap.ui.xmlfragment("com.aramco.fion.fdbZFI_FION_FDB.fragments.costCenter", this);
			//this.getView().addDependent(this.costcenter);
			this.getCostCenterFromDate(oMonth, oYear);
		},
		getCostCenterFromDate: function (M, Y) {
			var _this = this;
			var IsDataPresent = [];
			this.setDefaultModel();
			var oJsonModel = new sap.ui.model.json.JSONModel();
			if (this.costcenter) {
				this.costcenter.destroy();
			}
			this.costcenter = sap.ui.xmlfragment("com.aramco.fion.fdbZFI_FION_FDB.fragments.costCenter", this);
			sap.ui.getCore().byId("id_selected_cc").setValue("");
			this.getView().addDependent(this.costcenter);
			this.getCostCentreHier(M, Y).then(function (result) {
				var a = result;
				if (a.length === 0) {
					oJsonModel.setData({
						"Items": {
							children: []
						}
					});
					sap.ui.getCore().byId("tree").setModel(oJsonModel);
					_this.getView().byId("costcenter_val").setValue("");
					_this.getView().byId("costcenter_val_1").setValue("");
					_this.costcenterValue = "";
				} else {
					if (_this.costcenterValue !== "" || _this.costcenterValue !== undefined) {
						var costCenterVal = [_this.costcenterValue];
						IsDataPresent = a.filter(function (itm) {
							return costCenterVal.indexOf(itm.Data9) > -1;
						});
					}
					var s = _this.loadHierarchy(a);
					oJsonModel.setData({
						"Items": {
							children: s
						}
					});
					sap.ui.getCore().byId("tree").setModel(oJsonModel);
					var childNodes = "";
					var ccFlag = 0;
					//var oKey = _this.getView().byId("icontabbar").getSelectedKey();
					var oTree = sap.ui.getCore().byId("tree"); //to set select the [0]th master data 
					var oItems = oTree.getItems();
					oTree.setSelectedItem(oItems[0]);
					var oObj = oTree.getSelectedContexts()[0].getObject();
					var oPeriod = String(Y) + "0" + String(M);
					//var oJsonModel = new sap.ui.model.json.JSONModel();
					//var oObj = sap.ui.getCore().byId("tree").getSelectedContexts()[0].getObject();
					var oCostCenter = oObj.costcentre;
					if (IsDataPresent.length === 0) {
						_this.costcenterValue = "";
						_this.getView().byId("costcenter_val").setValue("");
						_this.getView().byId("costcenter_val_1").setValue("");
						sap.ui.getCore().byId("id_selected_cc").setValue(oObj.text + " (" + oObj.costcentre_1 + ")");
						_this.getView().byId("costcenter_val").setValue(oObj.text + " (" + oObj.costcentre_1 + ")");
						_this.costcenterValue = oObj.costcentre;
						_this.getView().byId("costcenter_val_1").setValue(oObj.costcentre);
					}
					_this.onExecutePress();
				}
			});

		},
		onCCSearch: function (oEvent) {
			var query = oEvent.getParameter("newValue").trim();
			/*sap.ui.getCore().byId("tree").getBinding("items").filter(query ? new sap.ui.model.Filter({
				path: "text",
				operator: "Contains",
				value1: query
			}) : null);*/
			if (query && query.length > 0) {
				var oFilter = new sap.ui.model.Filter({
					filters: [
						new sap.ui.model.Filter("text", sap.ui.model.FilterOperator.Contains, query),
						new sap.ui.model.Filter("costcentre_1", sap.ui.model.FilterOperator.Contains, query),
					],
					and: false
				})
				var oBinding = sap.ui.getCore().byId("tree").getBinding("items");
				oBinding.filter(oFilter, "Application");
				sap.ui.getCore().byId("tree").expandToLevel(query ? 100 : 1);
			} else {
				sap.ui.getCore().byId("tree").expandToLevel(1);
			}
		},
		onCostCenterPress: function () {
			var _this = this;
			this.costcenter.destroy();
			var oDate = this.getView().byId("date").getDateValue();
			var oMonth = oDate.getMonth() + 1;
			if (oMonth < 10) {
				oMonth = "0" + oMonth;
			}
			oMonth = "0" + oMonth;
			var oYear = oDate.getFullYear();
			var oView = this.getView();
			this.costcenter = sap.ui.xmlfragment("com.aramco.fion.fdbZFI_FION_FDB.fragments.costCenter", this);
			this.getView().addDependent(this.costcenter);
			_this.getCostCenter(oMonth, oYear, this.flag);
			this.flag = 0;
			sap.ui.getCore().byId("id_selected_cc").setValue(_this.getView().byId("costcenter_val").getValue());
			this.costcenter.open();
			/*if (!this.byId("id_costcenterDialog")) {
				Fragment.load({
					id: oView.getId(),
					name: "com.aramco.fi.dashboardZFI_DASHBOARD.fragments.costCenter",
					controller: _this
				}).then(function(oDialog) {
					oView.addDependent(oDialog);
					_this.getCostCenter(oMonth,oYear);
					jQuery.sap.syncStyleClass("sapUiSizeCompact", oView, oDialog);
					oDialog.open();
				});
			} else {

				_this.byId("C1DFDialog").open();
			}*/
		},
		getCostCenter: function (M, Y) {
			var _this = this;
			this.getCostCentreHier(M, Y).then(function (result) {
				var a = result;
				var s = _this.loadHierarchy(a);
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": {
						children: s
					}
				});
				sap.ui.getCore().byId("tree").setModel(oJsonModel);
				sap.ui.getCore().byId("tree").expandToLevel(1);
			});
		},
		closeCCDialog: function () {
			this.flag = 0;
			this.costcenter.destroy();
		},
		getChildNodes: function () {
			var obj = "";
			for (var i in this.aChilds) {
				if (parseInt(i) === this.aChilds.length - 1) {
					obj = obj + this.aChilds[i].cost_center;
				} else {
					obj = obj + this.aChilds[i].cost_center + "/";
				}
			}
			return obj;
		},
		getMonths: function (oVal) {
			if (oVal === "001") {
				return "Jan";
			} else if (oVal === "002") {
				return "Feb";
			} else if (oVal === "003") {
				return "Mar";
			} else if (oVal === "004") {
				return "Apr";
			} else if (oVal === "005") {
				return "May";
			} else if (oVal === "006") {
				return "Jun";
			} else if (oVal === "007") {
				return "Jul";
			} else if (oVal === "008") {
				return "Aug";
			} else if (oVal === "009") {
				return "Sep";
			} else if (oVal === "010") {
				return "Oct";
			} else if (oVal === "011") {
				return "Nov";
			} else if (oVal === "012") {
				return "Dec";
			}
		},
		onTabSelect: function (oEvent) {
			var ccFlag = 1;
			//var oKey = this.getView().byId("icontabbar").getSelectedKey();
			this.selectedKey = oEvent.getParameter("item").getKey();
			//this.onExecutePress();
			if (this.getView().byId("date").getValue() === "") {
				//sap.m.MessageToast.show("Please choose period!");
				return false;
			}
			if (this.getView().byId("costcenter_val").getValue() === "") {
				//sap.m.MessageToast.show("Please choose cost center!");
				return false;
			}
			var oKey = this.selectedKey;
			var oDate = this.getView().byId("date").getDateValue();
			var oMonth = oDate.getMonth() + 1;
			if (oMonth < 10) {
				oMonth = "0" + oMonth;
			}
			var oYear = oDate.getFullYear();
			var oPeriod = String(oYear) + "0" + String(oMonth);
			var childNodes = "";
			var oCostCenter = this.getView().byId("costcenter_val_1").getValue();
			if (oKey !== "TMG") {
				this.onExecutePress_1(oPeriod, oCostCenter, childNodes, oKey, ccFlag);
			} else {}
		},

		onTogglePressExeSum: function () {
			if (this.exeSumChartValue === undefined) {
				this.exeSumChartValue = "YTD"
			} else if (this.exeSumChartValue === "YTD") {
				this.exeSumChartValue = "Actual";
			} else if (this.exeSumChartValue === "Actual") {
				this.exeSumChartValue = "YTD";
			}
			this.executeDirectExpChart(this.globalData, this);
			console.log(this.globalData);
		},
		onTogglePressCCByOrg: function () {
			if (this.ccByOrgValue === undefined) {
				this.ccByOrgValue = "YTD"
			} else if (this.ccByOrgValue === "YTD") {
				this.ccByOrgValue = "Actual";
			} else if (this.ccByOrgValue === "Actual") {
				this.ccByOrgValue = "YTD";
			}
			this.executeCCByOrgChart(this.globalData, this);
			console.log(this.globalData);
		},

		onTogglePressOverTime: function () {
			if (this.overTimeValue === undefined) {
				this.overTimeValue = "YTD"
			} else if (this.overTimeValue === "YTD") {
				this.overTimeValue = "Actual";
			} else if (this.overTimeValue === "Actual") {
				this.overTimeValue = "YTD";
			}
			this.executeCCByOrgChart(this.globalData, this);
			console.log(this.globalData);
		},

		onTogglePressCC: function () {
			if (this.CCValue === undefined) {
				this.CCValue = "YTD"
			} else if (this.CCValue === "YTD") {
				this.CCValue = "Actual";
			} else if (this.CCValue === "Actual") {
				this.CCValue = "YTD";
			}
			this.executeDirectExpChart(this.globalData, this);
			console.log(this.globalData);
		},

		onTogglePressSST: function () {
			if (this.sstValue === undefined) {
				this.sstValue = "YTD"
			} else if (this.sstValue === "YTD") {
				this.sstValue = "Actual";
			} else if (this.sstValue === "Actual") {
				this.sstValue = "YTD";
			}
			this.executeSSTabChart(this.globalData, this);
			console.log(this.globalData);
		},

		onExecutePress: function () {
			var ccFlag = 0;
			//var oKey = this.getView().byId("icontabbar").getSelectedKey();
			var oKey = this.selectedKey;
			//this.onExecutePress();
			if (this.getView().byId("date").getValue() === "") {
				//sap.m.MessageToast.show("Please choose period!");
				return false;
			}
			if (this.getView().byId("costcenter_val").getValue() === "") {
				//sap.m.MessageToast.show("Please choose cost center!");
				return false;
			}
			var oDate = this.getView().byId("date").getDateValue();
			var oMonth = oDate.getMonth() + 1;
			if (oMonth < 10) {
				oMonth = "0" + oMonth;
			}
			var oYear = oDate.getFullYear();
			var oPeriod = String(oYear) + "0" + String(oMonth);
			var childNodes = "";
			var oCostCenter = this.getView().byId("costcenter_val_1").getValue();
			this.onExecutePress_1(oPeriod, oCostCenter, childNodes, oKey, ccFlag);
		},
		onAddCompTextPress: function () {
			var oKey = this.getView().byId("id_type_select").getSelectedKey();
			var oTableType = this.getView().byId("id_table_type").getSelectedKey();
			if (oKey === "" && oKey === undefined) {
				sap.m.MessageToast.show("Please select type");
				return false;
			}
			var oJsonModel = new sap.ui.model.json.JSONModel();
			this.createtextTable = sap.ui.xmlfragment("com.aramco.fion.fdbZFI_FION_FDB.fragments.textTable", this);
			oJsonModel.setData({
				"Ztab": oKey,
				"Type": oTableType
			});
			this.getView().addDependent(this.createtextTable);
			sap.ui.getCore().byId("id_text_create_frag").setModel(oJsonModel);
			sap.ui.getCore().byId("id_text_cr_type").setSelectedKey(oKey);
			this.onTypeChange_1(oKey);
			this.createtextTable.open();
		},
		onVarianceValidation: function (oVal) {
			if (oVal !== undefined && oVal !== null) {
				if (oVal.includes("-") === true) {
					oVal = oVal.substr(0, oVal.length - 1);
					oVal = Number(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0
					});
					oVal = "-" + oVal;
				} else {
					oVal = Number(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0
					});
				}
				return oVal;
			}
		},
		onChangeComponent_1: function (oKey) {
			sap.ui.getCore().byId("id_text_lab").setVisible(false);
			sap.ui.getCore().byId("id_text_input").setVisible(false);
			sap.ui.getCore().byId("id_combo_text_lab").setVisible(false);
			sap.ui.getCore().byId("id_combo_text").setVisible(false);
			if (oKey === "ES_SCORE_CARD" || oKey === "ES_DIREXP") {
				var b = this.getComponentIds(oKey);
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": b
				});
				this.getView().setModel(oJsonModel, "SubComponents");
				sap.ui.getCore().byId("id_combo_text_lab").setVisible(true);
				sap.ui.getCore().byId("id_combo_text").setVisible(true);
			} else {
				sap.ui.getCore().byId("id_text_lab").setVisible(true);
				sap.ui.getCore().byId("id_text_input").setVisible(true);
			}
		},
		onChangeComponent: function (oEvent) {
			var oKey = oEvent.getSource().getSelectedKey();
			this.onChangeComponent_1(oKey);
		},
		onEditChangeComponent_1: function (oKey) {
			sap.ui.getCore().byId("id_ed_text_lab").setVisible(false);
			sap.ui.getCore().byId("id_ed_text_input").setVisible(false);
			sap.ui.getCore().byId("id_ed_combo_text_lab").setVisible(false);
			sap.ui.getCore().byId("id_ed_combo_text").setVisible(false);
			if (oKey === "ES_SCORE_CARD" || oKey === "ES_DIREXP") {
				var b = this.getComponentIds(oKey);
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": b
				});
				this.getView().setModel(oJsonModel, "SubComponents");
				sap.ui.getCore().byId("id_ed_combo_text_lab").setVisible(true);
				sap.ui.getCore().byId("id_ed_combo_text").setVisible(true);
			} else {
				sap.ui.getCore().byId("id_ed_text_lab").setVisible(true);
				sap.ui.getCore().byId("id_ed_text_input").setVisible(true);
			}
		},
		onEditChangeComponent: function (oEvent) {
			var oKey = oEvent.getSource().getSelectedKey();
			this.onEditChangeComponent_1(oKey);
		},
		onCloseCompText: function () {
			this.createtextTable.destroy();
		},
		onAddPress: function () {
			var oKey = this.getView().byId("id_type_select").getSelectedKey();
			var oTableType = this.getView().byId("id_table_type").getSelectedKey();
			if (oKey === "" && oKey === undefined) {
				sap.m.MessageToast.show("Please select type");
				return false;
			}
			var oJsonModel = new sap.ui.model.json.JSONModel();
			this.newEntry = sap.ui.xmlfragment("com.aramco.fion.fdbZFI_FION_FDB.fragments.newEntry", this);
			oJsonModel.setData({
				"Zview": oKey,
				"Type": oTableType
			});
			this.getView().addDependent(this.newEntry);
			sap.ui.getCore().byId("id_create_frag").setModel(oJsonModel);
			sap.ui.getCore().byId("id_cr_type").setSelectedKey(oKey);
			this.newEntry.open();
		},
		onSubtypeChange: function (oEvent) {
			var oModel = sap.ui.getCore().byId("id_create_frag").getModel();
			var oData = oModel.getData();
			oData.ZcompText = oEvent.getSource().getSelectedItem().getText();
			oData.Zcomponent = oEvent.getSource().getSelectedKey();
			oModel.updateBindings();
		},
		onSaveCompText: function () {
			var _this = this;
			var oEntry = {};
			var oTableType = this.getView().byId("id_table_type").getSelectedKey();
			var oData = sap.ui.getCore().byId("id_text_create_frag").getModel().getData();
			oEntry = oData;
			oEntry.Action = "C";
			this.postEditData(oEntry).then(function (result) {
				var a = result;
				if (a.MessageType === "S") {
					sap.m.MessageToast.show(a.MessageText);
					_this.getRecords(oData.Ztab, oTableType);
					_this.createtextTable.destroy();
				} else {
					sap.m.MessageToast.show("Error");
				}
			});
		},
		onSaveNewEntry: function () {
			var _this = this;
			var oEntry = {},
				A;
			var oTableType = this.getView().byId("id_table_type").getSelectedKey();
			var presentItems = this.getView().byId("table_maint").getModel().getData().Items;
			var oData = sap.ui.getCore().byId("id_create_frag").getModel().getData();
			A = [oData.Zcomponent];
			var IsAvailableNew = presentItems.filter(function (itm) {
				return A.indexOf(itm.Zcomponent) > -1;
			});
			if (IsAvailableNew.length !== 0) {
				var IsAllowed = this.hasItems(oData.Zcomponent);
				if (IsAllowed === "1") {
					sap.m.MessageToast.show("Component is already present");
					return false;
				}
			}
			oEntry = oData;
			oEntry.Action = "C";
			this.postEditData(oEntry).then(function (result) {
				var a = result;
				if (a.MessageType === "S") {
					sap.m.MessageToast.show(a.MessageText);
					_this.getRecords(oData.Zview, oTableType);
					_this.newEntry.destroy();
				} else {
					sap.m.MessageToast.show("Error");
				}
			});

		},
		onCloseNewEntry: function () {
			this.newEntry.destroy();
		},
		onTextItemPress: function (oEvent) {
			var oItem = oEvent.getSource();
			var oTableType = this.getView().byId("id_table_type").getSelectedKey();
			var oObj = oEvent.getSource().getBindingContext().getObject();
			var oJsonModel = new sap.ui.model.json.JSONModel();
			oObj.Type = oTableType;
			oJsonModel.setData(oObj);
			//this.onTypeChange_1(oObj.Zview);
			this.edittextEntry = sap.ui.xmlfragment("com.aramco.fion.fdbZFI_FION_FDB.fragments.textTableEdit", this);
			this.getView().addDependent(this.edittextEntry);
			//this.onEditChangeComponent_1(oObj.Zcomponent);
			sap.ui.getCore().byId("id_text_edit_frag").setModel(oJsonModel);
			this.edittextEntry.open();
		},
		onCloseEditCompText: function () {
			this.edittextEntry.destroy();
		},
		onItemPress: function (oEvent) {
			var oItem = oEvent.getSource();
			var oTableType = this.getView().byId("id_table_type").getSelectedKey();
			var oObj = oEvent.getSource().getBindingContext().getObject();
			var oJsonModel = new sap.ui.model.json.JSONModel();
			oObj.Type = oTableType;
			oJsonModel.setData(oObj);
			this.onTypeChange_1(oObj.Zview);
			this.editEntry = sap.ui.xmlfragment("com.aramco.fion.fdbZFI_FION_FDB.fragments.editEntry", this);
			this.getView().addDependent(this.editEntry);
			sap.ui.getCore().byId("id_edit_frag").setModel(oJsonModel);
			//sap.ui.getCore("id_cost_elm_cat").setSelectedKey(oObj.Zcecate);
			this.editEntry.open();
		},
		onCloseEntry: function () {
			this.editEntry.destroy();
		},
		onDeleteCompText: function () {
			var _this = this;
			MessageBox.confirm("Are you sure you want to delete?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						_this.doDeleteCompText();
					}
				}
			});
		},
		doDeleteCompText: function () {
			var _this = this;
			var oEntry = {};
			var oTableType = this.getView().byId("id_table_type").getSelectedKey();
			var oData = sap.ui.getCore().byId("id_text_edit_frag").getModel().getData();
			oEntry = oData;
			oEntry.Action = "D";
			this.postEditData(oEntry).then(function (result) {
				var a = result;
				if (a.MessageType === "S") {
					sap.m.MessageToast.show(a.MessageText);
					_this.getRecords(oData.Ztab, oTableType);
					_this.edittextEntry.destroy();
				} else {
					sap.m.MessageToast.show("Error!");
				}
			});
		},
		onEditCompText: function () {
			var _this = this;
			var oEntry = {};
			var oTableType = this.getView().byId("id_table_type").getSelectedKey();
			var oData = sap.ui.getCore().byId("id_text_edit_frag").getModel().getData();
			oEntry = oData;
			oEntry.Action = "U";
			this.postEditData(oEntry).then(function (result) {
				var a = result;
				if (a.MessageType === "S") {
					sap.m.MessageToast.show(a.MessageText);
					_this.getRecords(oData.Ztab, oTableType);
					_this.edittextEntry.destroy();
				} else {
					sap.m.MessageToast.show("Error");
				}
			});
		},
		onCustomAction: function (oEvent) {
			this.getView().byId(oEvent.getSource().getParent().getContent()[0].getContent().getId()).setHeight("250px");
		},
		onDeleteEntry: function () {
			var _this = this;
			MessageBox.confirm("Are you sure you want to delete?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						_this.doDeleteEntry();
					}
				}
			});
		},
		doDeleteEntry: function () {
			var _this = this;
			var oEntry = {};
			var oTableType = this.getView().byId("id_table_type").getSelectedKey();
			var oData = sap.ui.getCore().byId("id_edit_frag").getModel().getData();
			oEntry = oData;
			oEntry.Action = "D";
			this.postEditData(oEntry).then(function (result) {
				var a = result;
				if (a.MessageType === "S") {
					sap.m.MessageToast.show(a.MessageText);
					_this.getRecords(oData.Zview, oTableType);
					_this.editEntry.destroy();
				} else {
					sap.m.MessageToast.show("Error!");
				}
			});
		},
		onSaveEditEntry: function () {
			var _this = this;
			var oEntry = {};
			var oTableType = this.getView().byId("id_table_type").getSelectedKey();
			var oData = sap.ui.getCore().byId("id_edit_frag").getModel().getData();
			oEntry = oData;
			oEntry.Action = "U";
			this.postEditData(oEntry).then(function (result) {
				var a = result;
				if (a.MessageType === "S") {
					sap.m.MessageToast.show(a.MessageText);
					_this.getRecords(oData.Zview, oTableType);
					_this.editEntry.destroy();
				} else {
					sap.m.MessageToast.show("Error");
				}
			});
		},
		onOKPress: function () {
			var _this = this;
			var ccFlag = 0;
			this.flag = 1;
			//var oSelectedKey = this.getView().byId("icontabbar").getSelectedKey();
			var childNodes = this.getChildNodes();
			if (this.getView().byId("date").getValue() === "") {
				//sap.m.MessageToast.show("Please choose period!");
				return false;
			}
			/*if (sap.ui.getCore().byId("tree").getSelectedContexts().length === 0) {
				sap.m.MessageToast.show("Please choose cost center!");
				return false;
			}*/
			//var oKey = this.getView().byId("icontabbar").getSelectedKey();
			var oKey = this.selectedKey;
			var oDate = this.getView().byId("date").getDateValue();
			var oMonth = oDate.getMonth() + 1;
			if (oMonth < 10) {
				oMonth = "0" + oMonth;
			}
			var oYear = oDate.getFullYear();
			var oPeriod = String(oYear) + "0" + String(oMonth);
			//var oJsonModel = new sap.ui.model.json.JSONModel();
			if (sap.ui.getCore().byId("tree").getSelectedContexts().length !== 0) {
				var oObj = sap.ui.getCore().byId("tree").getSelectedContexts()[0].getObject();
				var oCostCenter = oObj.costcentre;
				this.getView().byId("costcenter_val").setValue(oObj.text + " (" + oObj.costcentre_1 + ")");
				this.costcenterValue = oObj.costcentre;
				this.getView().byId("costcenter_val_1").setValue(oObj.costcentre);
				this.setDefaultModel();
				_this.onExecutePress();
			}
			//this.costcenter.destroy();
			var subnodes = "30002950/30002950A/30002956/30002955/30004259/30002949/30002982/30026862/30027516/30029970";
			//this.onExecutePress_1(oPeriod, oCostCenter, childNodes, oKey, ccFlag);
			_this.costcenter.destroy();
		},
		setDefaultModel: function () {
			var oJsonModel_1 = new sap.ui.model.json.JSONModel();
			oJsonModel_1.setData({
				"Items": []
			});
			this.getView().setModel(oJsonModel_1, "WorkforceByOrg");
			var oJsonModel_2 = new sap.ui.model.json.JSONModel();
			oJsonModel_2.setData({
				"Items": []
			});
			this.getView().setModel(oJsonModel_2, "CostByORg");
			var a = {};
			a.NavHeadertoItem1 = [];
			a.NavHeadertoItem2 = [];
			a.NavHeadertoItem3 = [];
			a.NavHeadertoItem4 = [];
			a.NavHeadertoItem5 = [];
			a.NavHeadertoItem6 = [];
			a.NavHeadertoItem7 = [];
			a.NavHeadertoItem8 = [];
			var oJsonModel = new sap.ui.model.json.JSONModel();
			oJsonModel.setData(a);
			this.getView().setModel(oJsonModel, "MainModel");
			this.getView().byId("id_tot_workforce").setText("0");
			this.getView().byId("id_work_saudi_num").setText("0");
			this.getView().byId("id_work_saudi_perc").setText("0%");
			this.getView().byId("id_work_expat_num").setText("0");
			this.getView().byId("id_work_expat_perc").setText("0%");
		},
		onExecutePress_1: function (oPeriod, oCostCenter, childNodes, oKey, Flag) {
			var _this = this;
			this.setClearModel(_this);
			var oJsonModel = new sap.ui.model.json.JSONModel();
			this.getExecutiveSummery(oPeriod, oCostCenter, childNodes, oKey).then(function (result) {
				_this.globalData = result;
				var a = result;
				//a[0].Node = oYear;
				oJsonModel.setData(a[0]);
				if (a[0].MessageType === "S") {
					if (Flag === 0) {
						//_this.costcenter.destroy();
						_this.getView().byId("icontabbar").setVisible(true);
					}
					if (oKey === "EXEC_SUMMARY") {
						if (a[0].NavHeadertoItem1.results) {
							//_this.setCardsData(a[0].NavHeadertoItem1.results, _this);
						}
						/*if (a[0].NavHeadertoItem2.results) {
							if (a[0].NavHeadertoItem2.results.length !== 0) {
								a[0].NavHeadertoItem2.results = _this.setExpenditure(a[0].NavHeadertoItem2.results);
							}
						}*/
						if (a[0].NavHeadertoItem5.results) {
							_this.lastGraphs(a[0].NavHeadertoItem5.results, _this);
						}
						_this.setExecChartProperties(_this);
						_this.executeDirectExpChart(result, _this);
						_this.setDirExpTable(a[0].NavHeadertoItem2.results, _this);
					} else if (oKey === "CONT_COST") {
						a[0].NavHeadertoItem4.results = _this.getFormat_1(a[0].NavHeadertoItem4.results);
						a[0].NavHeadertoItem5.results = _this.getFormat(a[0].NavHeadertoItem5.results);
						if (a[0].NavHeadertoItem6.results.length === 0) {
							a[0].NavHeadertoItem6.results.push({
								"Data2": "",
								"Data3": "",
								"Node": "",
								"Value": "",
							});
						}
						if (a[0].NavHeadertoItem8.results.length === 0) {
							a[0].NavHeadertoItem8.results.push({
								"Data1": "",
								"Data5": ""
							});
						}
						//_this.setContCostCards(a[0].NavHeadertoItem7.results, _this);
						_this.executeCCByOrgChart(result, _this);
						_this.setCont_CostChartProperties(_this);
						_this.setContCostOrgTable(a[0].NavHeadertoItem1.results, _this)
					} else if (oKey === "WORKFORCE") {
						_this.setWorkforceProperties(_this);
						_this.setWorkforceCards(_this, a[0].NavHeadertoItem2.results);
						_this.setWorkforceOrgTab(a[0].NavHeadertoItem1.results, _this);
						_this.setSaudisbyGradeTab(a[0].NavHeadertoItem3.results, _this);
						_this.setExpatbyGradeTab(a[0].NavHeadertoItem4.results, _this);
						_this.setSMPSaudibyGrade(a[0].NavHeadertoItem5.results, _this);
						_this.setSMPExaptbyGrade(a[0].NavHeadertoItem6.results, _this);
					} else if (oKey === "SUPPORT_SRV") {
						_this.setSupportServProperties(_this);
						_this.setSupServTab(a[0].NavHeadertoItem1.results, _this)
					}
					_this.getView().setModel(oJsonModel, "MainModel");
					_this.executeSSTabChart(result, _this);
					_this.getView().byId("icontabbar").setVisible(true);
					_this.getView().byId("id_selection_screen").setVisible(true);
					_this.getView().byId("id_overflowbar").setVisible(true);
				}
				//oJsonModel.setData({"Items": data});
				else if (a[0].MessageType === "E") {
					_this.setDefaultCardsData(_this);
					_this.setDefualtContCards(_this);
					//sap.m.MessageToast.show("No Record Found For the Selected Period!");
					sap.m.MessageToast.show(a[0].MessageText);
					_this.getView().byId("icontabbar").setVisible(true);
					_this.getView().byId("id_selection_screen").setVisible(true);
					_this.getView().byId("id_overflowbar").setVisible(true);
					return false;
				}
			});
		},

		executeDirectExpChart: function (dataArray, _this) {
			var results = [];
			var results2 = [];
			var title = dataArray[0].Data9;
			var ccTitle = dataArray[0].Data10;
			var ccDataArray = dataArray[0].NavHeadertoItem4["results"];
			dataArray = dataArray[0].NavHeadertoItem2["results"];
			if (this.exeSumChartValue === "Actual" || this.exeSumChartValue === undefined) {
				title = title + " " + "Month"
				if (Array.isArray(dataArray)) {
					for (var i = 0; i < dataArray.length; i++) {
						results.push({
							legend: dataArray[i].Component,
							type: dataArray[i].Data4,
							value: dataArray[i].Data6,
						});
					}
				}
			} else {
				title = title + " " + "YTD"
				if (Array.isArray(dataArray)) {
					for (var i = 0; i < dataArray.length; i++) {
						results.push({
							legend: dataArray[i].Component,
							type: dataArray[i].Data4,
							value: dataArray[i].Data5,
						});
					}
				}
			}
			if (this.CCValue === "Actual" || this.CCValue === undefined) {
				ccTitle = ccTitle + " " + "Month"
				if (Array.isArray(ccDataArray)) {
					for (var i = 0; i < ccDataArray.length; i++) {
						results2.push({
							legend: ccDataArray[i].Actual,
							type: ccDataArray[i].Data2,
							value: ccDataArray[i].Data3,
						});
					}
				}
			} else {
				ccTitle = ccTitle + " " + "YTD"
				if (Array.isArray(ccDataArray)) {
					for (var i = 0; i < ccDataArray.length; i++) {

						results2.push({
							legend: ccDataArray[i].Actual,
							type: ccDataArray[i].CostElement,
							value: ccDataArray[i].Period,
						});

					}
				}
			}

			var data = {
				"title": title,
				"NavHeadertoItem2": {
					"results": results
				}
			}

			var data2 = {
				"title": ccTitle,
				"NavHeadertoItem4": {
					"results": results2
				}
			}

			console.log(data2);

			var oJsonModel = new sap.ui.model.json.JSONModel();
			oJsonModel.setData(data);
			this.getView().setModel(oJsonModel, "executiveDirModel");

			var oJsonModel2 = new sap.ui.model.json.JSONModel();
			oJsonModel2.setData(data2);
			this.getView().setModel(oJsonModel2, "ccModel");
		},

		executeCCByOrgChart: function (dataArray, _this) {
			var results = [];
			var results2 = [];
			var title = dataArray[0].Data9;
			var overTimeTitle = dataArray[0].Data11;
			var overTimeDataArray = dataArray[0].NavHeadertoItem3["results"];
			dataArray = dataArray[0].NavHeadertoItem1["results"];

			if (this.ccByOrgValue === "Actual" || this.ccByOrgValue === undefined) {
				title = title + " " + "Month"
				if (Array.isArray(dataArray)) {
					for (var i = 0; i < dataArray.length; i++) {
						results.push({
							legend: dataArray[i].CostElement,
							type: dataArray[i].PlanVal,
							value: dataArray[i].Data1,
						});
					}
				}
			} else {
				title = title + " " + "YTD"
				if (Array.isArray(dataArray)) {
					for (var i = 0; i < dataArray.length; i++) {
						results.push({
							legend: dataArray[i].CostElement,
							type: dataArray[i].PlanVal,
							value: dataArray[i].Actual,
						});
					}
				}
			}

			if (this.overTimeValue === "Actual" || this.overTimeValue === undefined) {
				overTimeTitle = overTimeTitle + " " + "Month"
				if (Array.isArray(overTimeDataArray)) {
					for (var i = 0; i < overTimeDataArray.length; i++) {
						results2.push({
							legend: overTimeDataArray[i].CostElement,
							type: overTimeDataArray[i].Data6,
							value: overTimeDataArray[i].Data7,
						});
					}
				}
			} else {
				overTimeTitle = overTimeTitle + " " + "YTD"
				if (Array.isArray(overTimeDataArray)) {
					for (var i = 0; i < overTimeDataArray.length; i++) {
						results2.push({
							legend: overTimeDataArray[i].CostElement,
							type: overTimeDataArray[i].Component,
							value: overTimeDataArray[i].PlanVal,
						});
					}
				}
			}

			var data = {
				"title": title,
				"NavHeadertoItem1": {
					"results": results
				}
			}
			var data2 = {
				"title": overTimeTitle,
				"NavHeadertoItem3": {
					"results": results2
				}
			}
			console.log(data, data2, "Datas");
			var oJsonModel = new sap.ui.model.json.JSONModel();
			oJsonModel.setData(data);
			this.getView().setModel(oJsonModel, "ccByOrgModel");

			var oJsonModel2 = new sap.ui.model.json.JSONModel();
			oJsonModel2.setData(data2);
			this.getView().setModel(oJsonModel2, "overtimeModel");
		},

		executeSSTabChart: function (dataArray, _this) {
			var results = [];
			var title = dataArray[0].Data6;
			dataArray = dataArray[0].NavHeadertoItem3["results"];

			if (this.sstValue === "Actual" || this.sstValue === undefined) {
				title = title + " " + "Month"
				if (Array.isArray(dataArray)) {
					for (var i = 0; i < dataArray.length; i++) {
						results.push({
							legend: dataArray[i].Data2,
							type: dataArray[i].Data6,
							value: dataArray[i].Data7,
						});
					}
				}
			} else {
				title = title + " " + "YTD"
				if (Array.isArray(dataArray)) {
					for (var i = 0; i < dataArray.length; i++) {
						results.push({
							legend: dataArray[i].Data2,
							type: dataArray[i].Data1,
							value: dataArray[i].Data3,
						});
					}
				}
			}

			var data = {
				"title": title,
				"NavHeadertoItem3": {
					"results": results
				}
			}
			var oJsonModel = new sap.ui.model.json.JSONModel();
			oJsonModel.setData(data);
			this.getView().setModel(oJsonModel, "ssModel");

		},

		setWorkforceCards: function (_this, data) {
			var oTot = 0,
				exp_perc = 0,
				saudi_percent = 0,
				exp = 0,
				saudi = 0;
			if (data.length > 0) {
				for (var i in data) {
					oTot = 0;
					if (data[i].Component === "99991HCEXP") {
						exp = data[i].PlanVal;
						exp = parseInt(exp);
					} else if (data[i].Component === "99991HCSA") {
						saudi = data[i].PlanVal;
						saudi = parseInt(saudi);
					}
				}
				oTot = Number(exp) + Number(saudi);
				oTot = parseInt(oTot);
				exp_perc = (Number(exp) / Number(oTot)) * 100;
				exp_perc = parseInt(exp_perc);
				saudi_percent = (Number(saudi) / Number(oTot)) * 100;
				saudi_percent = parseInt(saudi_percent);
				oTot = oTot.toLocaleString('en-us', {
					minimumFractionDigits: 0
				});
				saudi = saudi.toLocaleString('en-us', {
					minimumFractionDigits: 0
				});
				exp = exp.toLocaleString('en-us', {
					minimumFractionDigits: 0
				});
			}
			_this.getView().byId("id_tot_workforce").setText(oTot);
			_this.getView().byId("id_work_saudi_num").setText(saudi);
			_this.getView().byId("id_work_saudi_perc").setText(saudi_percent + "%");
			_this.getView().byId("id_work_expat_num").setText(exp);
			_this.getView().byId("id_work_expat_perc").setText(exp_perc + "%");
		},
		setDirExpTable: function (data, _this) {
			var uniqueItems = [];
			$.each(data, function (j, el) {
				if (_this.inArray(uniqueItems, el) === false) {
					uniqueItems.push(el);
				}
			}.bind(_this));
			var newArray = [],
				obj = {};
			for (var k in uniqueItems) {
				var f = uniqueItems[k].Component;
				var newCollection = data.filter(function (el) {
					return el.Component === f;
				});
				for (var z in newCollection) {
					obj.Item = newCollection[z].Component;
					if (z === "0") {
						obj.Data1 = newCollection[z].Data5;
						obj.Data5 = newCollection[z].Data6;
					} else {
						obj.Data2 = newCollection[z].Data5;
						obj.Data6 = newCollection[z].Data6;
					}
				}
				obj.Data3 = this.getVariance(obj.Data1, obj.Data2);
				obj.Data4 = this.getVarianceNumber(obj.Data1, obj.Data2);
				newArray.push(obj), obj = {};
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": newArray
				});
				_this.getView().byId("id_table_water_fall").setModel(oJsonModel);
			}
		},
		inArray: function (array, el) {
			var find = false;
			$.each(array, function (index, value) {
				if (el.Component === value.Component) {
					find = true;
					return false;
				}
			});
			return find;
		},
		getFormat_1: function (data) {
			for (var i in data) {
				if (data[i].Actual.includes("-") === true) {
					data[i].Actual = data[i].Actual.substr(0, data[i].Actual.length - 1);
					/*oVal = Number(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0
					});*/
					data[i].Actual = "-" + data[i].Actual;
				}
			}
			return data;
		},
		getFormat: function (data) {
			for (var i in data) {
				if (data[i].Value.includes("-") === true) {
					data[i].Value = data[i].Value.substr(0, data[i].Value.length - 1);
					/*oVal = Number(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0
					});*/
					data[i].Value = "-" + data[i].Value;
				}
			}
			return data;
		},
		getAmountFormat_1: function (oVal) {
			if (oVal !== null && oVal !== "" && oVal !== undefined) {
				if (oVal.includes("-") === true) {
					oVal = oVal.substr(0, oVal.length - 1);
					oVal = Number(oVal);
					// oVal = Math.round(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0,
						maximumFractionDigits: 2
					});
					oVal = "( " + oVal + " )";
				} else {
					oVal = Number(oVal);
					//	oVal = Math.round(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0,
						maximumFractionDigits: 2
					});
				}
			}
			return oVal;
		},
		onAmountFormat: function (oVal) {
			if (oVal !== null && oVal !== "" && oVal !== undefined) {
				if (oVal.includes("-") === true) {
					if (oVal.substr(0, 1) === "-") {
						oVal = oVal.substr(1, oVal.length);
					} else {
						oVal = oVal.substr(0, oVal.length - 1);
					}
					oVal = Number(oVal);
					oVal = Math.round(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0,
						maximumFractionDigits: 2
					});
					oVal = "( " + oVal + " )";
				} else {
					oVal = Number(oVal);
					oVal = Math.round(oVal);
					oVal = oVal.toLocaleString('en-us', {
						minimumFractionDigits: 0,
						maximumFractionDigits: 2
					});
				}
			}
			return oVal;
		},
		setSupportServProperties: function (_this) {
			var oVizframe_1 = _this.getView().byId("viz_sup_serv_org");
			oVizframe_1.setVizProperties({
				title: {
					//text: "Support Services by org"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				legendGroup: {
					layout: {
						position: "bottom"
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					},
					//colorPalette: ["#00b7eb", "#84db00"]
					colorPalette: ["#00a3e0", "#84bd00"]
				}
			});
			var oSupServ = this.getView().byId("id_popover_sup_serv_org");
			oSupServ.connect(oVizframe_1.getVizUid());
			var oVizframe_2 = _this.getView().byId("id_viz_sup_serv_trend");
			oVizframe_2.setVizProperties({
				title: {
					//text: "Support Services Trend"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				legendGroup: {
					layout: {
						position: "bottom"
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					},
					//colorPalette: ["#00b7eb", "#84db00"]
					colorPalette: ["#00a3e0", "#84bd00"]
				}
			});
			var oSupServTrend = this.getView().byId("id_popover_sup_serv_trend");
			oSupServTrend.connect(oVizframe_2.getVizUid());
		},
		lastGraphs: function (data, _this) {
			var a = [];
			var b = [];
			for (var i in data) {
				if (data[i].Catagory === "Cost By Org") {
					a.push(data[i]);
				}
				/*else if (data[i].Catagory === "Workforce By Org") {
					b.push(data[i]);
				}*/
			}
			var oJsonModel = new sap.ui.model.json.JSONModel();
			/*var oJsonModel_1 = new sap.ui.model.json.JSONModel();*/
			oJsonModel.setData({
				"Items": a
			});
			/*oJsonModel_1.setData({
				"Items": b
			});*/
			_this.getView().setModel(oJsonModel, "CostByORg");
			/*_this.getView().setModel(oJsonModel_1, "WorkforceByOrg");*/
			//}	
		},
		onLogout: function () {
			MessageBox.confirm("Are you sure you want to logout?", {
				actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.CANCEL],
				styleClass: "sapUiSizeCompact",
				onClose: function (sAction) {
					if (sAction === "YES") {
						window.open("about:blank", "_self");
					}
				}
			});
			// sessionStorage.clear();
			// window.close();
		},
		getVarState: function (oVal) {
			if (oVal === "#00843D") {
				return "Success";
			} else if (oVal === "#FF3300") {
				return "Error";
			} else if (oVal === "#FFA500") {
				return "Warning";
			} else if (oVal === "") {
				return "None";
			}
		},
		getClass: function (oVal) {
			if (oVal === "#00843D") {
				return "contentGreen";
			} else if (oVal === "#FF3300") {
				return "contentRed";
			} else {
				return "contentBlack";
			}
		},
		onSelectCC: function (oEvent) {
			var _this = this;
			_this.aChilds = [];
			var aItems = oEvent.getParameter("listItems");
			var oObj = oEvent.getSource().getSelectedContexts()[0].getObject();
			sap.ui.getCore().byId("id_selected_cc").setValue(oObj.text + " (" + oObj.costcentre_1 + ")");
			jQuery.each(aItems, function (iIndex, oItem) {
				var oNode = oItem.getBindingContext().getObject();
				if (oNode.children) {
					_this.addChildItems(oNode.children, _this);
				}
			});
		},
		addChildItems: function (aNodes, _this) {
			jQuery.each(aNodes, function (iIndex, oNodes) {
				_this.aChilds.push({
					"cost_center": oNodes.costcentre
				});
			});
		},
		setExpenditure: function (odata) {
			var total = ["TOTAL"];
			var totalData = odata.filter(function (itm) {
				return total.indexOf(itm.Component) > -1;
			});
			var filerData = odata.filter(i => i.Component !== "TOTAL");
			for (var j in totalData) {
				filerData.push(totalData[j]);
			}
			return filerData;
		},
		onTableTypeChange: function (oEvent) {
			var oKey = oEvent.getSource().getSelectedKey();
			var Type = this.getView().byId("id_type_select").getSelectedKey();
			if (Type !== "" && oKey !== "") {
				this.getRecords(Type, oKey);
			}
		},
		onTypeChange: function (oEvent) {
			var oKey = oEvent.getSource().getSelectedKey();
			var tableType = this.getView().byId("id_table_type").getSelectedKey();
			this.onTypeChange_1(oKey);
			if (tableType !== "" && oKey !== "") {
				this.getRecords(oKey, tableType);
			}
		},
		onTypeChange_1: function (oKey) {
			var subType = this.getSubType(oKey);
			var oJsonModel = new sap.ui.model.json.JSONModel();
			oJsonModel.setData({
				"Items": subType
			});
			this.getView().setModel(oJsonModel, "SubTypes");
		},
		getRecords: function (ViewKey, TableType) {
			var _this = this;
			this.getMaintRecords(ViewKey, TableType).then(function (result) {
				var a = result;
				var oJsonModel = new sap.ui.model.json.JSONModel();
				oJsonModel.setData({
					"Items": a
				});
				_this.getView().byId("table_maint").setModel(oJsonModel);
				_this.getView().byId("text_table_maint").setModel(oJsonModel);
				_this.getView().byId("table_maint").setVisible(false);
				_this.getView().byId("text_table_maint").setVisible(false);
				if (TableType === "Master") {
					_this.getView().byId("table_maint").setVisible(true);
				} else if (TableType === "Text") {
					_this.getView().byId("text_table_maint").setVisible(true);
				}
			});
		},
		setWorkforceProperties: function (_this) {
			var oVizframe_1 = _this.getView().byId("viz_workforce_org");
			oVizframe_1.setVizProperties({
				title: {
					//text: "Workforce by org"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					},
					//colorPalette: ["#00b7eb", "#84db00"]
					colorPalette: ["#00a3e0", "#84bd00"]
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			var oWorkforceOrg = this.getView().byId("id_popover_workforce_org");
			oWorkforceOrg.connect(oVizframe_1.getVizUid());
			var oVizframe_2 = _this.getView().byId("viz_saudis_by_grade");
			oVizframe_2.setVizProperties({
				title: {
					//text: "Saudis by Grade"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					},
					//colorPalette: ["#00b7eb", "#84db00"]
					colorPalette: ["#00a3e0", "#84bd00"]
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			var oSaudisGrade = this.getView().byId("id_popover_saudis_by_grade");
			oSaudisGrade.connect(oVizframe_2.getVizUid());
			var oVizframe_3 = _this.getView().byId("viz_expat_by_grade");
			oVizframe_3.setVizProperties({
				title: {
					//text: "Expat by Grade"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					},
					//colorPalette: ["#00b7eb", "#84db00"]
					colorPalette: ["#00a3e0", "#84bd00"]
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			var oExpatGrade = this.getView().byId("id_popover_expat_by_grade");
			oExpatGrade.connect(oVizframe_3.getVizUid());
			var oVizframe_4 = _this.getView().byId("viz_smp_saudi_by_grade");
			oVizframe_4.setVizProperties({
				title: {
					//text: "Saudis by Grade(SMP)"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					},
					//colorPalette: ["#00b7eb", "#84db00"]
					colorPalette: ["#00a3e0", "#84bd00"]
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			var oSmpSaudisGrade = this.getView().byId("id_popover_smp_saudi_by_grade");
			oSmpSaudisGrade.connect(oVizframe_4.getVizUid());
			var oVizframe_5 = _this.getView().byId("viz_smp_expat_by_grade");
			oVizframe_5.setVizProperties({
				title: {
					//text: "Expat by Grade(SMP)"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					},
					//colorPalette: ["#00b7eb", "#84db00"]
					colorPalette: ["#00a3e0", "#84bd00"]
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			var oSmpExaptGrade = this.getView().byId("id_popover_smp_expat");
			oSmpExaptGrade.connect(oVizframe_5.getVizUid());
			var oVizframe_6 = _this.getView().byId("id_viz_work_donut");
			oVizframe_6.setVizProperties({
				title: {
					text: ""
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataLabel: {
						visible: true
					},
					//colorPalette: ["#00a3e0", "#84bd00", "red", "orange", "yellow", "blue"]
					colorPalette: ["#00a3e0", "#84bd00", "#676a6e", "#808080", "#c0c0c0", "#dadada", "#00843d", "#0033a0"]
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			var oWorkDonut = this.getView().byId("id_popover_work_donut");
			oWorkDonut.connect(oVizframe_6.getVizUid());
		},
		setCont_CostChartProperties: function (_this) {
			var oVizframe_1 = _this.getView().byId("viz_cont_cost_org");
			oVizframe_1.setVizProperties({
				title: {
					//text: "Controllable cost by org"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				legendGroup: {
					layout: {
						position: "bottom"
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					},
					//colorPalette: ["#00b7eb", "#84db00"]
					colorPalette: ["#00a3e0", "#84bd00"]
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			var oContCostOrg = this.getView().byId("id_popover_cont_cost_org");
			oContCostOrg.connect(oVizframe_1.getVizUid());
			var oVizframe_2 = _this.getView().byId("id_viz_dir_contr_cost");
			oVizframe_2.setVizProperties({
				title: {
					//text: "Direct Controllable cost by org"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				legendGroup: {
					layout: {
						position: "bottom"
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					},
					//colorPalette: ["#00a3e0", "#84bd00", "red", "orange", "yellow", "blue"]
					colorPalette: ["#00a3e0", "#84bd00", "#676a6e", "#dadada", "#c0c0c0", "#808080", "#00843d", "#0033a0"]
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			var oDirContCostOrg = this.getView().byId("id_popover_dir_cont_cost");
			oDirContCostOrg.connect(oVizframe_2.getVizUid());
			var oVizframe_3 = _this.getView().byId("id_viz_overtime");
			oVizframe_3.setVizProperties({
				title: {
					//text: "Overtime [cost/hours]"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				legendGroup: {
					layout: {
						position: "bottom"
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					},
					//colorPalette: ["#00b7eb", "#84db00"]
					colorPalette: ["#00a3e0", "#84bd00"]
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			var oOvertime = this.getView().byId("id_popover_overtime");
			oOvertime.connect(oVizframe_3.getVizUid());
			var oVizframe_4 = _this.getView().byId("id_viz_rec_capex");
			oVizframe_4.setVizProperties({
				title: {
					//text: "Recoveries to capex"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataLabel: {
						visible: true
					},
					//colorPalette: ["#00a3e0", "#84bd00", "red", "orange", "yellow", "blue"]
					colorPalette: ["#00a3e0", "#84bd00", "#676a6e", "#808080", "#c0c0c0", "#dadada", "#00843d", "#0033a0"]
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			var oRecCapex = this.getView().byId("id_popover_rec_capex");
			oRecCapex.connect(oVizframe_4.getVizUid());
			var oVizframe_5 = _this.getView().byId("id_viz_serv_inc_cost");
			oVizframe_5.setVizProperties({
				title: {
					//text: "Service income cost recovery"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataLabel: {
						visible: true
					},
					//colorPalette: ["#00a3e0", "#84bd00", "red", "orange", "yellow", "blue"]
					colorPalette: ["#00a3e0", "#84bd00", "#676a6e", "#808080", "#c0c0c0", "#dadada", "#00843d", "#0033a0"]
				},
				interaction: {
					selectability: {
						mode: "single"
					}
				}
			});
			var oServIncCost = this.getView().byId("id_popover_serv_inc_cost");
			oServIncCost.connect(oVizframe_5.getVizUid());
		},
		setExecChartProperties: function (_this) {
			var oVizframe = _this.getView().byId("viz_water_fall");
			oVizframe.setVizProperties({
				title: {
					//text: "Direct Expenditure"
					visible: false
				},
				valueAxis: {
					label: {
						formatString: 'u'
					},
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				legendGroup: {
					layout: {
						position: "bottom"
					}
				},
				plotArea: {
					dataLabel: {
						formatString: "0,,##.M",
						visible: false
					},
					//colorPalette: ["#00b7eb", "#84db00"]
					colorPalette: ["#00a3e0", "#84bd00"]
				}
				/*	interaction: {
						selectability: {
							mode: "single"
						}
					}*/
			});
			var oWaterFallPop = this.getView().byId("id_popover_water_fall");
			oWaterFallPop.connect(oVizframe.getVizUid());
			var oVizframe_1 = _this.getView().byId("id_support_serv");
			oVizframe_1.setVizProperties({
				title: {
					//text: "Support Services (Top 5)"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					}
				}
				/*interaction: {
					selectability: {
						mode: "single"
					}
				}*/
			});
			var oSupportPop = this.getView().byId("id_popover_support");
			oSupportPop.connect(oVizframe_1.getVizUid());
			var oVizframe_2 = _this.getView().byId("id_contr_cost");
			oVizframe_2.setVizProperties({
				title: {
					//text: "Controllable Cost"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				legendGroup: {
					layout: {
						position: "bottom"
					}
				},
				plotArea: {
					dataLabel: {
						visible: false
					},
					//colorPalette: ["#00b7eb", "#84db00"]
					colorPalette: ["#00a3e0", "#84bd00"]
				}
				/*interaction: {
					selectability: {
						mode: "single"
					}
				}*/
			});
			var oContrCostPop = this.getView().byId("id_popover_contr_cost");
			oContrCostPop.connect(oVizframe_2.getVizUid());
			var oVizframe_3 = _this.getView().byId("id_cost_by_org");
			oVizframe_3.setVizProperties({
				title: {
					//text: "Cost By Org"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataLabel: {
						visible: true
					},
					//colorPalette: ["#00a3e0", "#84bd00", "red", "orange", "yellow", "blue"]
					colorPalette: ["#00a3e0", "#84bd00", "#676a6e", "#808080", "#c0c0c0", "#dadada", "#00843d", "#0033a0"]
				}
				/*interaction: {
					selectability: {
						mode: "single"
					}
				}*/
			});
			var oCostByOrg = this.getView().byId("id_popover_cost_by_org");
			oCostByOrg.connect(oVizframe_3.getVizUid());
			var oVizframe_4 = _this.getView().byId("id_work_by_org");
			oVizframe_4.setVizProperties({
				title: {
					//text: "Workforce By Org"
					visible: false
				},
				valueAxis: {
					title: {
						visible: false
					}
				},
				categoryAxis: {
					title: {
						visible: false
					}
				},
				plotArea: {
					dataLabel: {
						visible: true
					},
					//colorPalette: ["#00a3e0", "#84bd00", "red", "orange", "yellow", "blue"]
					colorPalette: ["#00a3e0", "#84bd00", "#676a6e", "#808080", "#c0c0c0", "#dadada", "#00843d", "#0033a0"]
				}
				/*interaction: {
					selectability: {
						mode: "single"
					}
				}*/
			});
			var oWorkByOrg = this.getView().byId("id_popover_work_by_org");
			oWorkByOrg.connect(oVizframe_4.getVizUid());
		},
		onArrowUp: function () {
			this.getView().byId("id_selection_screen").setVisible(false);
			this.getView().byId("id_arrow_down").setVisible(true);
			this.getView().byId("id_arrow_up").setVisible(false);
		},
		onArrowDown: function () {
			this.getView().byId("id_selection_screen").setVisible(true);
			this.getView().byId("id_arrow_up").setVisible(true);
			this.getView().byId("id_arrow_down").setVisible(false);
		},
		onDecimalFormat: function (oVal) {
			if (oVal !== null && oVal !== "" && oVal !== undefined) {
				if (oVal.includes("-") === true) {
					oVal = oVal.substr(0, oVal.length - 1);
					oVal = parseInt(oVal);
					if (isNaN(oVal)) {
						oVal = 0;
					} else {
						oVal = oVal.toLocaleString('en-us');
						oVal = "( " + oVal + " )";
					}
				} else {
					oVal = parseInt(oVal);
					if (isNaN(oVal)) {
						oVal = 0;
					} else {
						oVal = oVal.toLocaleString('en-us');
					}
				}
			}
			return oVal;
		}

	});
});